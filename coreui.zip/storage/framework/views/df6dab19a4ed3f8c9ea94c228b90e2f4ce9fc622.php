<?php if($menus->count() >= 1): ?>

    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="row menuListWrap">
            <div class="col-sm-3">
                <div class="menuListImage" style="background-image:url('<?php echo e($menu->image); ?>');"></div>
            </div>
            <div class="col-sm-9">
                <span class="siteColor"><b><?php echo e($menu->menu); ?></b></span><br>
                <small><?php echo e($menu->description); ?></small><br>
                <span class="text-success"><b>&#8358; <?php echo e($menu->price); ?></b></span><br>
                <small>
                    <a href="javascript:void()" data-href="<?php echo e(route('vendor.menu.edit.form', ['id' => $menu->id])); ?>" id="editMenuBtn">Edit</a> &nbsp; / &nbsp;
                    <a href="javascript:void()" data-href="<?php echo e(route('vendor.menu.delete', ['id' => $menu->id])); ?>" id="deleteMenuBtn">Delete</a> &nbsp;
                    <?php if($menu->category != NULL): ?>
                    / &nbsp;
                    <?php if($menu->stock == 0): ?>
                        <a href="javascript:void()" id="toggleMenuStock" data-href="<?php echo e(route('vendor.menu.stock', ['id' => $menu->id])); ?>">Add to stock</a>
                    <?php else: ?>
                        <a href="javascript:void()" id="toggleMenuStock" data-href="<?php echo e(route('vendor.menu.stock', ['id' => $menu->id])); ?>">Remove from stock</a>
                    <?php endif; ?>
                    <?php endif; ?>
                </small>
            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php else: ?>
    <div class="alert alert-secondary">Oops No Menu here</div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\coreui\resources\views/vendor/pages/ajax/menu_list.blade.php ENDPATH**/ ?>