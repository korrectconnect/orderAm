<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <strong>Locations</strong>
                    </div>
                    <div class="card-body " style="max-height: 400px; overflow:auto;">
                        <?php if($locations->count() >= 1): ?>
                            <table class="table table-responsive-sm table-striped">
                                <thead>
                                    <tr>
                                        <th>Location</th>
                                        <th>Assigned Riders</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($location->name); ?></td>
                                            <td><?php echo e($location->location_assigned); ?></td>
                                            <td><a href="javascript:void();"  data-href="<?php echo e(route('admin.rider.location.assign', ['location' => $location->name])); ?>" id="viewRiderAssignBtn">View</a></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <div class="alert alert-secondary">
                                    No rider has been assigned to any location yet
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <strong>Rider List</strong>
                    </div>
                    <div class="card-body" id="viewRiderAssignDiv">
                        <i>Click on <b>view</b> to see list of riders assigned to a location here</i>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coreui\resources\views/admin/pages/rider/location.blade.php ENDPATH**/ ?>