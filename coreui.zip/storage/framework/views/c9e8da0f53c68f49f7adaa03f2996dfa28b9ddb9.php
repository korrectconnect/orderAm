<?php if(!auth()->user()): ?>
    <div class="alert alert-secondary">
        <small><b>Login to view cart</b></small>
    </div>
<?php else: ?>
    <?php if($carts->count() >= 1): ?>
        <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="clearfix cart-items">
                <div class="pull-left">
                <div class="update-product">
                    <a title="Increase item quantity" href="javascript:void()" id="increase-cart-btn" data-id="<?php echo e($cart->id); ?>"><i class="fa fa-plus-circle"></i></a>
                    <a title="Decrease item quantity" href="javascript:void()" id="decrease-cart-btn" data-id="<?php echo e($cart->id); ?>"><i class="fa fa-minus-circle"></i></a>
                </div>
                </div>
                    <div class="cart-product-name pull-left"><?php echo e($cart->name); ?></div>
                    <span class="cart-product-price pull-right text-spl-color pull-left">Qty: <?php echo e($cart->quantity); ?></span>
                    <div class="cart-product-price pull-right text-spl-color f-r"><b>&#8358; <?php echo e($cart->price*$cart->quantity); ?></b></div>
                    <div class="remove-cart-btn" ><a title="delete item from cart" id="remove-cart-btn" data-id="<?php echo e($cart->id); ?>" href="javascript:void()"><i class="fa fa-trash"></i></a></div>
                </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="alert alert-secondary">
            <small><b><i class="fa fa-shopping-cart"></i> cart for this vendor is empty</b></small>
        </div>
    <?php endif; ?>
<?php endif; ?>
<hr>

<div class="cart-amount">
    Order Amount : <span>&#8358
        <?php if(auth()->user()): ?>
            <?php if($carts->count() >= 1): ?>
                <?php echo e($order_total); ?>

            <?php else: ?>
                0
            <?php endif; ?>
        <?php else: ?>
            0
        <?php endif; ?>
    </span>
</div>
<div class="cart-amount">
    Delivery Charge : <span>&#8358
        <?php if(auth()->user()): ?>
            <?php if($carts->count() >= 1): ?>
                <?php echo e($vendor->delivery_charge); ?>

            <?php else: ?>
                0
            <?php endif; ?>
        <?php else: ?>
            0
        <?php endif; ?>
    </span>
</div>
<div class="cart-amount">
    Tax : <span>&#8358
        <?php if(auth()->user()): ?>
            <?php if($carts->count() >= 1): ?>
                <?php echo e($vendor->vendor_charge + $vendor->tax); ?>

            <?php else: ?>
                0
            <?php endif; ?>
        <?php else: ?>
            0
        <?php endif; ?>
    </span>
</div>

<div class="cart-amount" id="couponDiv" >
    Coupon : <span>&#8358 <span id="couponSpan"></span> </span>
</div>
<hr>

<div class="cart-amount">
    <b>Total</b> : <span>&#8358
        <?php if(auth()->user()): ?>
            <?php if($carts->count() >= 1): ?>
            <span id="orderTotal"><?php echo e($total); ?></span>
            <?php else: ?>
                0
            <?php endif; ?>
        <?php else: ?>
            0.00
        <?php endif; ?>
    </span>
</div>
<input type="hidden" id="orderTotalHidden" value="<?php echo e($total); ?>">
<input type="hidden" id="mCoupon" value="">
<?php /**PATH C:\xampp\htdocs\coreui\resources\views/user/ajax/cart.blade.php ENDPATH**/ ?>