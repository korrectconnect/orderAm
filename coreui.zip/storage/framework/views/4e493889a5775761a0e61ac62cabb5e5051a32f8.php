<form id="addMenuCategoryForm" data-href="<?php echo e(route('vendor.menu_category.add')); ?>">
    <?php echo csrf_field(); ?>

    <div class="form-group">
        <label for="category">Category</label>
        <input name="category" class="form-control menu-input" id="category" type="text" placeholder="Eg Drinks">
      </div>

      <input type="hidden" name="vendor_id" class="vendor_id">

      <button type="submit" class="btn btn-sm btn-primary" id="addMenuCategoryFormBtn">Add Category</button>

</form>
<?php /**PATH C:\xampp\htdocs\coreui\resources\views/vendor/pages/ajax/add_category_form.blade.php ENDPATH**/ ?>