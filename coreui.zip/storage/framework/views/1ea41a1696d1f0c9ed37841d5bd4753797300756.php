<?php $__env->startSection('content'); ?>

<div class="col-lg-12">
    <div class="card">
      <div class="card-header"><i class="fa fa-align-justify"></i> <b>All Vendors</b></div>
      <div class="card-body">
        <table class="table table-responsive-sm table-striped">
          <thead>
            <tr>
              <th>Name</th>
              <th>Type</th>
              <th>Date registered</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr id="vendor_<?php echo e($each->id); ?>">
                    <td><?php echo e($each->name); ?></td>
                    <td><?php echo e($each->type); ?></td>
                    <td><?php echo e(date('H:m, d/m/Y',strtotime($each->updated_at))); ?></td>
                    <td>
                        <?php if($each->status == 1): ?>
                            <span class="badge badge-success">Active</span>
                        <?php else: ?>
                            <span class="badge badge-danger">Suspended</span>
                        <?php endif; ?>
                    </td>
                    <td style="font-size:12px;">
                        <a href="javascript:void()" data-toggle="modal" data-target="#myModal" id="view_btn_<?php echo e($each->id); ?>" data-id="<?php echo e($each->id); ?>">View</a> /
                        <a href="<?php echo e(route('admin.vendor.finance', ['id' => $each->id])); ?>" >Finance</a> /
                        <a href="<?php echo e(route('admin.vendor.edit.form', ['id' => $each->id])); ?>" >Edit</a> /
                        <a href="javascript:void()" data-toggle="modal" data-target="#deleteModal" id="delete_vendor_<?php echo e($each->id); ?>" data-id="<?php echo e($each->id); ?>">Delete</a>

                        <script>

                            $("#view_btn_<?php echo e($each->id); ?>").click(function() {
                                $(".vendor-modal-title").html("<?php echo e($each->name); ?>");
                                $(".vendor-modal-body").html("<center><i class='fa fa-spinner fa-2x fa-spin'></i></center>");
                                $("#moreVendorID").val("<?php echo e($each->id); ?>");
                                var id = $(this).data('id');
                                $.ajax({
                                    url: "ajax/viewVendor/" + id,
                                    method: 'get',
                                    success: function(data) {
                                        $(".vendor-modal-body").html(data);
                                    }
                                });
                            });

                            $("#delete_vendor_<?php echo e($each->id); ?>").click(function() {
                                $("#deleteVendorName").html("<?php echo e($each->name.'('.$each->lga.')'); ?>");
                                $("#delete_vendor_link").val("<?php echo e(route('admin.vendor.delete',['id' => $each->id])); ?>");
                                $("#delete_vendor_id").val("<?php echo e($each->id); ?>");
                            });

                        </script>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        <?php if($query->count() >= 10): ?>

            <ul class="pagination">
            <li class="page-item"><a class="page-link" href="#">Prev</a></li>
            <li class="page-item active"><a class="page-link" href="#">1</a></li>
            <li class="page-item"><a class="page-link" href="#">2</a></li>
            <li class="page-item"><a class="page-link" href="#">3</a></li>
            <li class="page-item"><a class="page-link" href="#">4</a></li>
            <li class="page-item"><a class="page-link" href="#">Next</a></li>
            </ul>

        <?php endif; ?>
      </div>
    </div>
  </div>

  <script src="<?php echo e(asset('js/req.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coreui\resources\views/admin/pages/vendor/view.blade.php ENDPATH**/ ?>