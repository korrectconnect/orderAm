<?php $__env->startSection('content'); ?>

    <div class="admin-container-wrapper">

        <div class="container">

            <div class="GridLex-gap-15-wrappper">

                <div class="GridLex-grid-noGutter-equalHeight">

                    <?php echo $__env->make('vendor.inc.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div class="GridLex-col-9_sm-8_xs-12">

                        <div class="admin-content-wrapper">

                            <h2>Profile</h2>

                            <div class="profile-cover" style="background-image: url('<?php echo e($vendor->cover); ?>');"></div>

                            <div class="profile-image shadow" style="background-image: url('<?php echo e($vendor->image); ?>');"></div>

                            <br>

                            <div class="row">
                                <div class="col-md-3"></div>

                                <div class="col-md-9">
                                    <div class="card">
                                        <div class="card-body">
                                            <div>
                                                Name : <b><?php echo e($vendor->name); ?></b>
                                            </div>
                                            <div>
                                                Type : <b><?php echo e($vendor->type); ?></b>
                                            </div>
                                            <div>
                                                Address : <b><?php echo e($vendor->address); ?></b>
                                            </div>
                                            <div>
                                                Location : <b><?php echo e($vendor->lga.", ".$vendor->state); ?></b>
                                            </div>
                                            <div>
                                                Operation time : <b>
                                                    <?php
                                                        if($vendor->opening >= 12 && $vendor->opening < 13) {
                                                            echo $open_time = $vendor->opening." pm" ;
                                                        }else {
                                                            if ($vendor->opening >= 13) {
                                                                echo $open_time = ($vendor->opening - 12)." pm" ;
                                                            }else {
                                                                echo $open_time = $vendor->opening." am" ;
                                                            }
                                                        }
                                                    ?> -
                                                    <?php
                                                        if($vendor->closing >= 12 && $vendor->closing < 13) {
                                                            echo $close_time = $vendor->closing." pm" ;
                                                        }else {
                                                            if ($vendor->closing >= 13) {
                                                                echo $close_time = ($vendor->closing - 12)."0 pm" ;
                                                            }else {
                                                                echo $close_time = $vendor->closing." am" ;
                                                            }
                                                        }
                                                    ?>
                                                </b>
                                            </div>
                                            <div>
                                                About : <b><?php echo e($vendor->description); ?></b>
                                            </div>
                                            <div>
                                                Delivery Charge : <b><?php echo e($vendor->delivery_charge); ?></b>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coreui\resources\views/vendor/pages/profile.blade.php ENDPATH**/ ?>