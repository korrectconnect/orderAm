<form action="<?php echo e(route('admin.menu_category.add')); ?>" method="POST" id="addcategoryForm">
    <?php echo csrf_field(); ?>

    <div class="form-group">
        <label for="category">Category</label>
        <input name="category" class="form-control menu-input" id="category" type="text" placeholder="Eg Drinks">
      </div>

      <input type="hidden" name="vendor_id" class="vendor_id">

      <button type="submit" class="btn btn-sm btn-primary addMenuCategoryBtn">Add Category</button>

</form>
<?php /**PATH C:\xampp\htdocs\coreui\resources\views/admin/ajax/add_category_form.blade.php ENDPATH**/ ?>