
<h3 class="siteColor">Hi <?php echo e($user->firstname); ?>,</h3>
<h4>Add new address</h4>
	<!-- Border -->
	<div class="bor bg-orange"></div>
	<!-- Form -->
	<form class="form" role="form" id="addAddressForm" method="POST" data-href="<?php echo e(route('user.address')); ?>">
		<!-- Form Group -->
		<div class="form-group">
			<!-- Label -->
			<label class="control-label">City*</label>
			<!-- Input -->
			<select class="form-control" name="state">
                <?php if($states->count() >= 1): ?>
                    <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option><?php echo e($state->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
		</div>
		<div class="form-group">
			<!-- Label -->
			<label class="control-label">Area*</label>
			<!-- Input -->
			<select class="form-control" name="lga">
                <?php if($lgas->count() >= 1): ?>
                    <?php $__currentLoopData = $lgas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option><?php echo e($lga->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
        </div>
        <div class="form-group">
            <!-- Label -->
            <label class="control-label">Address*</label>
            <!-- Input -->
            <textarea type="text" name="address" class="form-control" rows="2"  placeholder="Enter address"></textarea>
        </div>
        <div class="form-group">
            <!-- Label -->
            <label class="control-label">Description</label>
            <!-- Input -->
            <input type="text" name="description" class="form-control"  placeholder="Eg. Black gate, 2nd floor etc">
        </div>
        <div class="form-group">
            <!-- Label -->
            <label class="control-label">Default Phone</label>
            <!-- Input -->
            <input type="text" class="form-control"  value="<?php echo e($user->phone); ?>" disabled>
        </div>

        <div class="form-group">
            <!-- Label -->
            <label class="control-label">Other Phone</label>
            <!-- Input -->
            <input type="text" onkeypress="return isNumberKey(event)" name="phone" class="form-control"  placeholder="">
        </div>

		<div class="form-group">
			<!-- Button -->
			<button type="submit" class="btn btn-primary" id="addAddressFormBtn">Submit</button>
		</div>
	</form>
<?php /**PATH C:\xampp\htdocs\coreui\resources\views/user/ajax/address.blade.php ENDPATH**/ ?>