<?php if($categories->count() >= 1): ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="vendor-category-image-div" style="background-image: url('<?php echo e($category->image); ?>')"></div>
                                    </div>
                                    <div class="col-sm-8">
                                        <br>
                                        <span style="font-size: 18px; color:rgb(243, 177, 54);"><strong><?php echo e($category->name); ?></strong></span><br>
                                        <span style="font-size: 13px;"><?php echo e($category->description); ?></span>
                                        <button class="btn btn-sm btn-link" id="deleteVendorCategoryBtn" data-id="<?php echo e($category->id); ?>" style="margin-top:-40px; float:right;"><i class="fa fa-trash fa-1x text-danger"></i></button>
                                    </div>
                                </div><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="alert alert-danger">
                                <small>You have not added any category for vendors <i class="fa fa-exclamation"></i></small>
                            </div>
                        <?php endif; ?>
<?php /**PATH C:\xampp\htdocs\coreui\resources\views/admin/pages/ajax/vendor_category.blade.php ENDPATH**/ ?>