<?php $__env->startSection('content'); ?>

    <div class="row null">

        <div class="col-md-6">
            <div class="card">
            <div class="card-header"><i class="fa fa-align-justify"></i> <b>Menu List</b>
                <a href="javascript:void()" style="float:right;" id="add_menu_btn" data-toggle="modal" data-target="#AddMenuFormModal" data-id="<?php echo e($vendor->id); ?>">Add Menu</a>
            </div>
            <div class="card-body">
                <a href="javascript:void()" id="refreshMenuBtn" onclick="refreshMenu(<?php echo e($vendor->id); ?>);">Refresh</a><br><br>
                <div style="width:100%; height:auto;" class="refreshMenuDiv card-overflow">
                  <?php if($menus->count() >= 1): ?>
                      <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="menu-vendor-div">
                          <div class="row null">
                              <div class="col-sm-4">
                                  
                                  <img src="<?php echo e(asset('storage/menu/'.$menu->image)); ?>" style="width:80px; height:80px; border-radius:10px;" alt="">
                              </div>
                              <div class="col-sm-8">
                                  <div class="menu-vendor-txt">
                                      <b><?php echo e($menu->menu); ?></b><br>

                                      <span style="font-size:12px;">
                                          <?php echo e($menu->name); ?>

                                      </span><br>

                                      <small><?php echo e($menu->category." . ".$menu->description); ?></small><br>

                                      <div style="display:inline-block; float:right; font-size:13px; color:rgb(0, 0, 150); margin-top:-60px;">
                                           &#8358; <?php echo e($menu->price); ?>

                                      </div>

                                      <div style="display:inline-block; float:right; font-size:12px; margin-top:-20px;">
                                        <a href="javascript:void()" id="deleteMenu_<?php echo e($menu->id); ?>" data-id="<?php echo e($menu->id); ?>" data-link="<?php echo e(route('admin.menu.delete',['id' => $menu->id])); ?>" style="color:rgb(150, 0, 0);"><i class='fa fa-trash'></i> Delete</a>
                                        <script>
                                            $("#deleteMenu_<?php echo e($menu->id); ?>").click(function() {
                                                var link = $(this).data("link");
                                                $("#deleteMenu_<?php echo e($menu->id); ?>").html("<i class='fa fa-spin fa-spinner'></i>");

                                                deleteMenu(link);
                                            });
                                        </script>
                                    </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                  <div style="font-size: 14px; width: 100%; height:auto; text-align:center; padding-top:13px;" >No Menu Added<br><p><a href="javascript:void()" id="add_menu_btn" data-toggle="modal" data-target="#AddMenuFormModal" data-id="<?php echo e($vendor->id); ?>">Add Menu</a></p></div>
                  <?php endif; ?>
                </div>
              </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card">
            <div class="vendor-image card-img-top" style="background-image:url(<?php echo e(asset('storage/vendor/'.$vendor->image)); ?>); height:250px;"></div>
                <div class="card-body">
                    <b><?php echo e($vendor->name." . ".$vendor->lga); ?></b>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">
                        category
                        <button class="btn btn-sm btn-link addCategoryLink" data-id="<?php echo e($vendor->id); ?>" style="float:right;" data-toggle="modal" data-target="#menuCategoryModal">Add</button>
                    </h4>

                    <div class="card-text">
                        <?php if($categories->count() >= 1): ?>
                            <form action="<?php echo e(route('admin.menu_category.delete')); ?>" method="post" class="deleteMenuCategoryForm">
                                <input type="hidden" name="category_id" class="category_id" >
                            </form>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="category-label bg-info"><?php echo e($category->category); ?> &nbsp; <button data-id="<?php echo e($category->id); ?>" class="btn btn-sm btn-link deleteMenuCategory" style="color:#fff; margin-top:-4px;">X</button></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <center>Opps no category added yet. <a href="javascript:void()" data-toggle="modal" data-target="#menuCategoryModal" class="addCategoryLink" data-id="<?php echo e($vendor->id); ?>">Add Category</a></center>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if($categories->count() >= 1): ?>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <script>
                appendMenuCategory("<?php echo e($category->category); ?>");
            </script>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <script>
        $("#add_menu_btn").click(function() {
            $(".modal-title").html("<?php echo e($vendor->name); ?> &nbsp; &nbsp; <span style='font-size:12px;'><?php echo e($vendor->type.' . '.$vendor->lga); ?></span>");
            //$(".modal-body").html("<center><i class='fa fa-spinner fa-2x fa-spin'></i></center>");
            var id = $(this).data('id');
            $("#vendor_id").val(id);
            $("#menu_refresh_id").attr("data-id","<?php echo e($vendor->id); ?>");
        });
    </script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coreui\resources\views/admin/menus/view.blade.php ENDPATH**/ ?>