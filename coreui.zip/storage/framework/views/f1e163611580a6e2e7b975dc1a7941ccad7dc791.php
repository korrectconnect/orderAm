

<?php if($riders->count() >= 1): ?>

<div class="alert alert-secondary" style="font-weight: bold;"><i class="fa fa-location-arrow"></i> . <?php echo e($location); ?></div>

<table class="table table-responsive-sm table-striped">
    <thead>
        <tr>
            <th>Fullname</th>
            <th>Category</th>
            <th>Description</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $riders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href="<?php echo e(route('admin.rider.single', ['id' => $rider->id])); ?>"><?php echo e($rider->firstname." ".$rider->lastname); ?></a></td>
                <td><?php echo e($rider->category); ?></td>
                <td><?php echo e($rider->location_description); ?></td>
                <td><a href="javascript:void();" data-href="<?php echo e(route('admin.rider.unassign', ['id' => $rider->id])); ?>" id="unassignRiderBtn">Unassign</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php else: ?>
    <div class="alert alert-secondary">
        No Rider has been assigned to <b><?php echo e($location); ?></b>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\coreui\resources\views/admin/pages/ajax/assigned_riders.blade.php ENDPATH**/ ?>