<li class="c-sidebar-nav-item">
    <a class="c-sidebar-nav-link" href="<?php echo e(route('admin.dashboard')); ?>">
        <i class="fa fa-pencil"></i> &nbsp; &nbsp;
        Dashboard
    </a>
</li>

<li class="c-sidebar-nav-item">
    <a class="c-sidebar-nav-link" href="<?php echo e(route('admin.orders')); ?>">
        <i class="fa fa-pencil"></i> &nbsp; &nbsp;
        Orders
    </a>
</li>

<li class="c-sidebar-nav-dropdown">
    <a class="c-sidebar-nav-dropdown-toggle" href="#">
        <i class="fa fa-pencil"></i> &nbsp; &nbsp;
        Vendors
    </a>

        <div class="c-sidebar-nav-dropdown-items">
            <a class="dropdown-item" href="<?php echo e(route('admin.vendor.add')); ?>">
                <i class="fa fa-pencil"></i> &nbsp; &nbsp;
                Add Vendor
            </a>
            <a class="dropdown-item" href="<?php echo e(route('admin.vendor.view')); ?>">
                <i class="fa fa-pencil"></i> &nbsp; &nbsp;
                View All
            </a>
            <a class="dropdown-item" href="<?php echo e(route('admin.vendor.category')); ?>">
                <i class="fa fa-pencil"></i> &nbsp; &nbsp;
                Vendor Category
            </a>
            <a class="dropdown-item" href="<?php echo e(route('admin.vendor.location')); ?>">
                <i class="fa fa-pencil"></i> &nbsp; &nbsp;
                Vendor Location
            </a>
        </div>

</li>

<li class="c-sidebar-nav-dropdown">
    <a class="c-sidebar-nav-dropdown-toggle" href="#">
        <i class="fa fa-pencil"></i> &nbsp; &nbsp;
        Riders
    </a>

        <div class="c-sidebar-nav-dropdown-items">
            <a class="dropdown-item" href="<?php echo e(route('admin.rider.add')); ?>">
                <i class="fa fa-pencil"></i> &nbsp; &nbsp;
                Register Rider
            </a>
            <a class="dropdown-item" href="<?php echo e(route('admin.rider.view')); ?>">
                <i class="fa fa-pencil"></i> &nbsp; &nbsp;
                View All Riders
            </a>
            <a class="dropdown-item" href="<?php echo e(route('admin.rider.locations')); ?>">
                <i class="fa fa-pencil"></i> &nbsp; &nbsp;
                View Assigned Locations
            </a>
            <a class="dropdown-item" href="<?php echo e(route('admin.rider.category')); ?>">
                <i class="fa fa-pencil"></i> &nbsp; &nbsp;
                Riders Category
            </a>
        </div>

</li>

<li class="c-sidebar-nav-item">
    <a class="c-sidebar-nav-link" href="<?php echo e(route('admin.menus')); ?>">
        <i class="fa fa-pencil"></i> &nbsp; &nbsp;
        Menus
    </a>
</li>

<li class="c-sidebar-nav-item">
    <a class="c-sidebar-nav-link" href="">
        <i class="fa fa-pencil"></i> &nbsp; &nbsp;
        Transactions
    </a>
</li>

<li class="c-sidebar-nav-item">
    <a class="c-sidebar-nav-link" href="">
        <i class="fa fa-pencil"></i> &nbsp; &nbsp;
        Customers
    </a>
</li>

<li class="c-sidebar-nav-item">
    <a class="c-sidebar-nav-link" href="">
        <i class="fa fa-pencil"></i> &nbsp; &nbsp;
        Settings
    </a>
</li>




<?php /**PATH C:\xampp\htdocs\coreui\resources\views/admin/shared/sidebar.blade.php ENDPATH**/ ?>