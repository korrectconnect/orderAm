
<form enctype="multipart/form-data" id="editMenuForm" data-href="<?php echo e(route('vendor.menu.edit')); ?>">
    <?php echo csrf_field(); ?>

    <div class="row null">
        <div class="col-sm-6">
            <b><small>Add Menu cover</small></b>

            <div class="cover-container">
                <div class="cover-image" style="background-image:url('<?php echo e($menu->image); ?>')"></div>
                <div class="cover-txt">Click here to add image from file </div>
            </div>
        </div>

        <div class="col-sm-6">
            <b><small>Enter Menu Info</small></b>

                  <div class="form-group">
                    <label for="name">Name</label>
                    <input name="name" class="form-control menu-input" id="name" type="text" value="<?php echo e($menu->menu); ?>" placeholder="Enter menu name/title">
                  </div>
                  <div class="form-group">
                    <label for="description">Description</label>
                    <input name="description" class="form-control menu-input" id="description" value="<?php echo e($menu->description); ?>" type="text" placeholder="Eg With cheese / 1 portion / 3 Pieces">
                  </div>
                  <div class="form-group">
                      <label for="category">Category</label>
                      <select name="category" class="form-control">
                          <?php if($menu_categories->count() >= 1): ?>
                            <option value="<?php echo e($menu->category); ?>" selected><?php echo e($menu->category); ?></option>
                            <?php $__currentLoopData = $menu_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($menu->category != $category->category): ?>
                                    <option value="<?php echo e($category->category); ?>"><?php echo e($category->category); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>
                      </select>
                    </div>
                  <div class="row null">
                    <div class="col-sm-6">
                    <div class="form-group">
                        <label for="price">Price</label>
                        <input name="price" class="form-control menu-input" value="<?php echo e($menu->price); ?>" id="price" type="text" placeholder="1900.99">
                    </div>
                    </div>

                   <div class="col-sm-6"><br>
                        <input type="file" name="cover" class="menu-input" style="display:none;" id="cover-file">
                        <input type="hidden" name="id" value="<?php echo e($menu->id); ?>">
                        <button type="submit" class="btn btn-primary btn-sm" id="editMenuFormBtn" style="float:right;">Edit Menu</button>
                    </div>
                  </div>

        </div>
    </div>
    </form>


<?php /**PATH C:\xampp\htdocs\coreui\resources\views/vendor/pages/ajax/edit_menu.blade.php ENDPATH**/ ?>