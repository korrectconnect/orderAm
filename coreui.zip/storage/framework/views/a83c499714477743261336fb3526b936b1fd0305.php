<div class="cover-image" style="background-image:url('<?php echo e($query->image); ?>');">

</div>

<small>Opening Hour : <?php echo e($query->opening); ?> | Closing Hour : <?php echo e($query->closing); ?> </small><br><br>


<div class="row">
    <div class="col-sm-6">
        <table class="table table-striped">
            <tbody>
                <tr>
                    <td><b>Name</b></td>
                    <td><?php echo e($query->name); ?></td>
                </tr>
                <tr>
                    <td><b>Type</b></td>
                    <td><?php echo e($query->type); ?></td>
                </tr>
                <tr>
                    <td><b>Email</b></td>
                    <td><?php echo e($query->email); ?></td>
                </tr>
                <tr>
                    <td><b>Contact</b></td>
                    <td><?php echo e($query->contact); ?></td>
                </tr>
                <tr>
                    <td><b>Status</b></td>
                    <td>
                        <?php if($query->status == 1): ?>
                            <span class="badge badge-success">Active</span>
                        <?php else: ?>
                            <span class="badge badge-danger">Suspended</span>
                        <?php endif; ?>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="col-sm-6">
        <table class="table table-striped">
            <tbody>
                <tr>
                    <td><b>Address</b></td>
                    <td><?php echo e($query->address); ?></td>
                </tr>
                <tr>
                    <td><b>LGA</b></td>
                    <td><?php echo e($query->lga); ?></td>
                </tr>
                <tr>
                    <td><b>Zip</b></td>
                    <td><?php echo e($query->zip); ?></td>
                </tr>
                <tr>
                    <td><b>State</b></td>
                    <td><?php echo e($query->state); ?></td>
                </tr>
                <tr>
                    <td><b>Country</b></td>
                    <td><?php echo e($query->country); ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\coreui\resources\views/admin/pages/ajax/view_vendor.blade.php ENDPATH**/ ?>