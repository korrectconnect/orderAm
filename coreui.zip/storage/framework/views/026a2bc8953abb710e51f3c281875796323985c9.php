<?php if($menus->count() >= 1): ?>
                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="menu-vendor-div">
                    <div class="row null">
                        <div class="col-sm-4">
                            
                            <img src="<?php echo e(asset('storage/menu/'.$menu->image)); ?>" style="width:80px; height:80px; border-radius:10px;" alt="">
                        </div>
                        <div class="col-sm-8">
                            <div class="menu-vendor-txt">
                                <b><?php echo e($menu->menu); ?></b><br>

                                <span style="font-size:12px;">
                                    <?php echo e($menu->name); ?>

                                </span><br>

                                <small><?php echo e($menu->category." . ".$menu->description); ?></small><br>

                                <div style="display:inline-block; float:right; font-size:13px; color:rgb(0, 0, 150); margin-top:-60px;">
                                     &#8358; <?php echo e($menu->price); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <div style="font-size: 14px; width: 100%; height:auto; text-align:center; padding-top:13px;" >No Menu Added<br><p><small>Click on a vendor to add menu</small></p></div>
            <?php endif; ?>
<?php /**PATH C:\xampp\htdocs\coreui\resources\views/admin/ajax/viewQuickMenu.blade.php ENDPATH**/ ?>