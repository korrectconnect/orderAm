<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="col-md-12">
        <div class="alert alert-secondary">
            <h3><?php echo e($vendor->name); ?></h3>
            <div class="orderMenuBtn" data-href="<?php echo e(route('admin.vendor.transaction.today', ['vendor_id' => $vendor->id])); ?>" >
                <i class="fa fa-clock"></i> Today's Transaction
            </div>
            <div class="orderMenuBtn" data-href="<?php echo e(route('admin.vendor.transaction.filter.form', ['vendor_id' => $vendor->id])); ?>" >
                <i class="fa fa-filter"></i> Filter
            </div>
        </div>

        <div class="card shadow-sm orderListDiv">
            <center><i class='fa fa-spin fa-circle-notch fa-2x'></i></center>
        </div><br>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coreui\resources\views/admin/pages/vendor/finance.blade.php ENDPATH**/ ?>