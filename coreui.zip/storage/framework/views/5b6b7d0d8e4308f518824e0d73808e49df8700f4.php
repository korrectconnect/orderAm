<li class="c-sidebar-nav-item">
    <a class="c-sidebar-nav-link" href="<?php echo e(route('admin.dashboard')); ?>">
        <i class="fa fa-pencil"></i> &nbsp; &nbsp;
        Dashboard
    </a>
</li>

<li class="c-sidebar-nav-dropdown">
    <a class="c-sidebar-nav-dropdown-toggle" href="#">
        <i class="fa fa-pencil"></i> &nbsp; &nbsp;
        Vendor
    </a>

        <div class="c-sidebar-nav-dropdown-items">
            <a class="dropdown-item" href="<?php echo e(route('admin.vendor.add')); ?>">
                <i class="fa fa-pencil"></i> &nbsp; &nbsp;
                Add
            </a>
            <a class="dropdown-item" href="<?php echo e(route('admin.vendor.view')); ?>">
                <i class="fa fa-pencil"></i> &nbsp; &nbsp;
                View All
            </a>
        </div>

</li>

<li class="c-sidebar-nav-item">
    <a class="c-sidebar-nav-link" href="<?php echo e(route('admin.menus')); ?>">
        <i class="fa fa-pencil"></i> &nbsp; &nbsp;
        Menus
    </a>
</li>

<li class="c-sidebar-nav-item">
    <a class="c-sidebar-nav-link" href="">
        <i class="fa fa-pencil"></i> &nbsp; &nbsp;
        Orders
    </a>
</li>

<li class="c-sidebar-nav-item">
    <a class="c-sidebar-nav-link" href="">
        <i class="fa fa-pencil"></i> &nbsp; &nbsp;
        Transactions
    </a>
</li>

<li class="c-sidebar-nav-item">
    <a class="c-sidebar-nav-link" href="">
        <i class="fa fa-pencil"></i> &nbsp; &nbsp;
        Customers
    </a>
</li>

<li class="c-sidebar-nav-item">
    <a class="c-sidebar-nav-link" href="">
        <i class="fa fa-pencil"></i> &nbsp; &nbsp;
        Settings
    </a>
</li>




<?php /**PATH C:\xampp\htdocs\chopnow\resources\views/admin/shared/sidebar.blade.php ENDPATH**/ ?>