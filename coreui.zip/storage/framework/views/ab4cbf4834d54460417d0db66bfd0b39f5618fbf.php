<footer class="c-footer">
  <div><a href="kocots.com">Kocots</a> &copy; <?php echo e(date('Y')); ?>.</div>
  <div class="ml-auto">Powered by&nbsp;<a href="kocots.com">Korrect Connect</a></div>
</footer>
<?php /**PATH C:\xampp\htdocs\coreui\resources\views/admin/shared/footer.blade.php ENDPATH**/ ?>