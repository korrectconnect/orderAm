
<div class="card-header">
    <strong>
        <?php if($cancelled == 1): ?>
            <i class="siteColor fa fa-times-circle"></i> Cancelled Orders
        <?php else: ?>
            <?php if($status == 0): ?>
                <i class="siteColor fa fa-list"></i> Incoming Orders
            <?php elseif($status == 1): ?>
                <i class="siteColor fa fa-biking"></i> Pending Delivery
            <?php elseif($status == 2): ?>
                <i class="siteColor fa fa-check-circle"></i> Delivered
            <?php endif; ?>
        <?php endif; ?>
    </strong>
</div>

<div class="card-body">
    <?php if($orders->count() >= 1): ?>
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th><i class="fa fa-clock"></i></th>
                    <th>Order no.</th>
                    <th>Payment Mode</th>
                    <th>Total</th>
                    <th>Delivery Time</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>

            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($order->created_at); ?></td>
                    <td><?php echo e($order->order_no); ?></td>
                    <td><?php echo e($order->payment_mode); ?></td>
                    <td>&#8358;<?php echo e($order->total); ?></td>
                    <td>
                        <?php if($order->delivery_time == NULL): ?>
                            As  soon as possible
                        <?php else: ?>
                            <?php echo e($order->delivery_time); ?>

                        <?php endif; ?>
                    </td>
                    <td><a data-href="<?php echo e(route('vendor.ajax.order', ['order_no' => $order->order_no])); ?>" href="javascript:void()" id="view_order">View</a></td>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
    <?php else: ?>
        <center>
            <p><i class="fa fa-search"></i>&nbsp; No order here</p>
        </center>
    <?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\coreui\resources\views/vendor/pages/ajax/orders.blade.php ENDPATH**/ ?>