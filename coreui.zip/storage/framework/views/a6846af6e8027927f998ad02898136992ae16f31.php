<?php $__env->startSection('content'); ?>

    <div class="admin-container-wrapper">

        <div class="container">

            <div class="GridLex-gap-15-wrappper">

                <div class="GridLex-grid-noGutter-equalHeight">

                    <?php echo $__env->make('vendor.inc.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div class="GridLex-col-9_sm-8_xs-12">

                        <div class="admin-content-wrapper">

                            <div class="admin-section-title">

                                <h2>Orders</h2>

                            </div>

                            <div class="table-responsivve">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th><i class="fa fa-clock"></i></th>
                                            <th>Order no.</th>
                                            <th>Payment Mode</th>
                                            <th>Total</th>
                                            <th>Delivery Time</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if($orders->count() >= 1): ?>
                                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <tr>
                                                    <td><?php echo e($order->created_at); ?></td>
                                                    <td><?php echo e($order->order_no); ?></td>
                                                    <td>&#8358;<?php echo e($order->payment_mode); ?></td>
                                                    <td><?php echo e($order->total); ?></td>
                                                    <td>
                                                        <?php if($order->delivery_time == NULL): ?>
                                                            As  soon as possible
                                                        <?php else: ?>
                                                            <?php echo e($order->delivery_time); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td><a href="#">View</a></td>
                                                </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coreui\resources\views/vendor/index.blade.php ENDPATH**/ ?>