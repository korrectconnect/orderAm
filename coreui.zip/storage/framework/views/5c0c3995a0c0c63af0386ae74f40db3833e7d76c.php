<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <strong>Transactions</strong>
                </div>
                <div class="card-body">

                    <div class="row">

                        <div class="col-md-3">
                            <div style="float: left; display:inline-block">
                                <span>Total Profit (Commission) :</span><br>
                                <?php if($profit > 0): ?>
                                <span class="text-success" style="font-size: 32px;">&#8358;<?php echo e($profit); ?></span>
                                <?php else: ?>
                                <span class="text-danger" style="font-size: 32px;">&#8358;<?php echo e($profit); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div style="float: left; display:inline-block">
                                <span>Total Sale :</span><br>
                                <?php if($total > 0): ?>
                                <span class="text-warning" style="font-size: 32px;">&#8358;<?php echo e($total); ?></span>
                                <?php else: ?>
                                <span class="text-danger" style="font-size: 32px;">&#8358;<?php echo e($total); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div style="float: left; display:inline-block">
                                <span>Total Order :</span><br>
                                <span style="font-size: 32px;"><?php echo e($transactions->count()); ?></span>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div style="float: left; display:inline-block">
                                <span>Delivered :</span><br>
                                <span style="font-size: 32px;"><?php echo e($delivered); ?></span>
                            </div>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Order no.</th>
                                    <th>Total</th>
                                    <th>Commission</th>
                                    <th>Vendor</th>
                                    <th>Payment Mode</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($transactions->count() >= 1): ?>
                                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($transaction->created_at); ?></td>
                                            <td><?php echo e($transaction->order_no); ?></td>
                                            <td>&#8358; <?php echo e($transaction->total); ?></td>
                                            <td><span class="text-success"><?php echo e($transaction->commission); ?>% (&#8358;<?php echo e(($transaction->total * $transaction->commission)/100); ?>)</span></td>
                                            <td><?php echo e($transaction->name." (".$transaction->lga.")"); ?></td>
                                            <td><?php echo e($transaction->payment_mode); ?></td>
                                            <td>
                                                <?php if($transaction->cancelled == 0): ?>
                                                    <span class="text-success">Delivered</span>
                                                <?php else: ?>
                                                    <span class="text-danger">Cancelled</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coreui\resources\views/admin/pages/transactions.blade.php ENDPATH**/ ?>