<?php $__env->startSection('content'); ?>

<div class="col-lg-12">
    <div class="card">
      <div class="card-header"><i class="fa fa-align-justify"></i> <b>All Riders</b></div>
      <div class="card-body">
        <table class="table table-responsive-sm table-striped">
          <thead>
            <tr>
              <th>Date registered</th>
              <th>Fullname</th>
              <th>City</th>
              <th>Status</th>
              <th>Location assigned</th>
              <th>Pending Orders</th>
              <th>company</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php if($riders->count() >= 1): ?>

                <?php $__currentLoopData = $riders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="rider_<?php echo e($rider->id); ?>">
                        <td><?php echo e($rider->created_at); ?></td>
                        <td><?php echo e($rider->firstname); ?> <?php echo e($rider->lastname); ?></td>
                        <td><?php echo e($rider->state); ?></td>
                        <td>
                            <?php if($rider->active == NULL || $rider->active == 0): ?>
                                <span class="badge badge-danger">Inactive</span>
                            <?php else: ?>
                                <span class="badge badge-success">Active</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($rider->location_assigned == NULL): ?>
                                <span class="text-danger">
                                    Unassigned
                                </span>
                            <?php else: ?>
                                <?php echo e($rider->location_assigned); ?>

                            <?php endif; ?>
                        </td>
                        <td><a href="javascript:void()" id="viewRiderOrdersBtn" data-href="<?php echo e(route('admin.ajax.rider.orders', ['id' => $rider->id])); ?>"><small>(click to view)</small></a></td>
                        <td>
                            <?php if($rider->company == NULL): ?>
                                <span class="text-warning">None</span>
                            <?php else: ?>
                                <span class="text-warning"><?php echo e($rider->company); ?></span>
                            <?php endif; ?>
                        </td>
                        <td style="font-size:12px;">

                            <a href="<?php echo e(route('admin.rider.single', ['id' => $rider->id])); ?>">View</a> &nbsp; / &nbsp;
                            <a href="javascript:void()" id="assignRiderBtn" data-href="<?php echo e(route('admin.rider.assign', ['id' => $rider->id])); ?>">Assign Location</a> &nbsp; / &nbsp;
                            <a href="<?php echo e(route('admin.rider.edit.form', ['id' => $rider->id])); ?>">Edit</a>

                        </td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </tbody>
        </table>
        <?php if($riders->count() >= 10): ?>

            <ul class="pagination">
            <li class="page-item"><a class="page-link" href="#">Prev</a></li>
            <li class="page-item active"><a class="page-link" href="#">1</a></li>
            <li class="page-item"><a class="page-link" href="#">2</a></li>
            <li class="page-item"><a class="page-link" href="#">3</a></li>
            <li class="page-item"><a class="page-link" href="#">4</a></li>
            <li class="page-item"><a class="page-link" href="#">Next</a></li>
            </ul>

        <?php endif; ?>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coreui\resources\views/admin/pages/rider/view.blade.php ENDPATH**/ ?>