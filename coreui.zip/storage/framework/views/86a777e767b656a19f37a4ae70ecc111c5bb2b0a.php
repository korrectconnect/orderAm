<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <strong>Pending Deliveries </strong>
                </div>
                <div class="card-body">

                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Order no.</th>
                                    <th>Total</th>
                                    <th>Vendor</th>
                                    <th>Payment Mode</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($orders->count() >= 1): ?>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($order->created_at); ?></td>
                                            <td><?php echo e($order->order_no); ?></td>
                                            <td>&#8358; <?php echo e($order->total); ?></td>
                                            <td><?php echo e($order->name." (".$order->lga.")"); ?></td>
                                            <td><?php echo e($order->payment_mode); ?></td>
                                            <td><a href="javascript:void()" id="viewPendingDeliveryBtn" data-href="<?php echo e(route('admin.pending.delivery', ['id' => $order->id])); ?>">View</a></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coreui\resources\views/admin/pages/pending.blade.php ENDPATH**/ ?>