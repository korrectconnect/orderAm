<br><br><br>
<footer class="footer-wrapper-area">


    <div class="bottom-footer">

        <div class="container">

            <div class="row">

                <div class="col-sm-4 col-md-4">

                    <p class="copy-right">&#169; Copyright 2016 iGlyphic</p>

                </div>

                <div class="col-sm-4 col-md-4">

                    <ul class="bottom-footer-menu">
                        <li><a href="#">Cookies</a></li>
                        <li><a href="#">Policies</a></li>
                        <li><a href="#">Terms</a></li>
                        <li><a href="#">Blogs</a></li>
                    </ul>

                </div>

                <div class="col-sm-4 col-md-4">
                    <ul class="bottom-footer-menu for-social">
                        <li><a href="#"><i class="ri ri-twitter" data-toggle="tooltip" data-placement="top" title="twitter"></i></a></li>
                        <li><a href="#"><i class="ri ri-facebook" data-toggle="tooltip" data-placement="top" title="facebook"></i></a></li>
                        <li><a href="#"><i class="ri ri-google-plus" data-toggle="tooltip" data-placement="top" title="google plus"></i></a></li>
                        <li><a href="#"><i class="ri ri-youtube-play" data-toggle="tooltip" data-placement="top" title="youtube"></i></a></li>
                    </ul>
                </div>

            </div>

        </div>

    </div>

</footer>
<?php /**PATH C:\xampp\htdocs\coreui\resources\views/vendor/inc/footer.blade.php ENDPATH**/ ?>