<?php $__env->startSection('content'); ?>

    <div class="admin-container-wrapper">

        <div class="container">

            <div class="GridLex-gap-15-wrappper">

                <div class="GridLex-grid-noGutter-equalHeight">

                    <?php echo $__env->make('vendor.inc.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div class="GridLex-col-9_sm-8_xs-12">

                        <div class="admin-content-wrapper">

                            <h2>Vendor Admin Authenticator</h2>

                            <?php if($auth == true): ?>
                                <p class="text-success" style="font-size: 15px;">Vendor Admin mode is active !</p><br>

                                <form action="<?php echo e(route('vendor.authAdminLogout')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-md btn-danger">Logout Admin Mode</button>
                                </form>
                            <?php else: ?>
                                <p class="text-danger" style="font-size: 15px;">Vendor Admin mode is not active !</p><br>

                                <form action="<?php echo e(route('vendor.authAdmin')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <label for="secret">Enter Admin Pin</label>
                                            <input type="password" name="secret" class="form-control">
                                        </div><br>
                                        <button type="submit" class="btn btn-md btn-danger">Authenticate</button>
                                    </div>
                                </form>
                            <?php endif; ?>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coreui\resources\views/vendor/pages/auth.blade.php ENDPATH**/ ?>