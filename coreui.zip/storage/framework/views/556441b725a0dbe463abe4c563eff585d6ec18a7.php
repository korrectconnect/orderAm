<form data-href="<?php echo e(route('admin.assign.rider')); ?>" id="assignRiderForm">
    <?php echo csrf_field(); ?>

    <h5><?php echo e($rider->firstname." ".$rider->lastname); ?></h5><br>

    <div class="form-group">
        <label for="state">City</label>
        <select name="state" class="form-control" id="state">
            <option><?php echo e($rider->state); ?></option>
        </select>
    </div>

    <div class="form-group">
        <label for="lga">L.G.A</label>
        <select name="lga" class="form-control" id="lga">
            <?php if($lgas->count() >= 1): ?>
                <?php $__currentLoopData = $lgas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option><?php echo e($lga->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </select>
    </div>

    <div class="form-group">
        <label for="description">Location Description</label>
        <input name="description" class="form-control menu-input" id="description" type="text" placeholder="">
    </div>

    <input type="hidden" name="rider_id" value="<?php echo e($rider->id); ?>">

    <button type="submit" class="btn btn-md btn-primary " id="assignRiderFormBtn" style="float: right;">Submit</button>

</form>
<?php /**PATH C:\xampp\htdocs\coreui\resources\views/admin/pages/ajax/assign_rider.blade.php ENDPATH**/ ?>