<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <form action="" method="POST" id="vendorCategoryForm">
                    <div class="card">
                        <div class="card-header">
                            <strong>Add Vendor Category</strong>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="vendor-category-upload-image"></div>
                                    <input type="file" name="cover" id="vendor-category-file" style="display:none;">
                                    <small>Click the above box to select file</small>
                                </div>

                                <div class="col-sm-8">
                                    <div class="form-group">
                                        <label for="name">Name</label>
                                        <input name="name" class="form-control" id="name" type="text" placeholder="Eg. Supermarket,Restaurant">
                                    </div>
                                    <div class="form-group">
                                        <label for="description">Description</label>
                                        <input name="description" class="form-control" id="description" type="text" placeholder="Eg. Foods you love">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button class="btn btn-primary btn-sm vendorCategoryBtn" style="float: right;">Continue</button>
                        </div>
                    </div>
                </form>
            </div>

            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <strong>Categories</strong>
                    </div>
                    <div class="card-body refreshVendorCategoryDiv">
                        <?php if($categories->count() >= 1): ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="vendor-category-image-div" style="background-image: url('<?php echo e($category->image); ?>')"></div>
                                    </div>
                                    <div class="col-sm-8">
                                        <br>
                                        <span style="font-size: 18px; color:rgb(243, 177, 54);"><strong><?php echo e($category->name); ?></strong></span><br>
                                        <span style="font-size: 13px;"><?php echo e($category->description); ?></span>
                                        <button class="btn btn-sm btn-link" id="deleteVendorCategoryBtn" data-id="<?php echo e($category->id); ?>" style="margin-top:-40px; float:right;"><i class="fa fa-trash fa-1x text-danger"></i></button>
                                    </div>
                                </div><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="alert alert-danger">
                                <small>You have not added any category for vendors <i class="fa fa-exclamation"></i></small>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coreui\resources\views/admin/pages/vendor/category.blade.php ENDPATH**/ ?>