<?php $__env->startSection('content'); ?>

<div class="breadcrumb-wrapper">

    <div class="container">

        <ol class="breadcrumb-list booking-step">
            <li><a href="#">Home</a></li>
            <li><span>Address Book</span></li>
        </ol>

    </div>

</div>
<!-- end breadcrumb -->

<div class="admin-container-wrapper">

    <div class="container">

        <div class="GridLex-gap-15-wrappper">

            <div class="GridLex-grid-noGutter-equalHeight">

                <div class="GridLex-col-3_sm-4_xs-12">

                    <div class="admin-sidebar">

                        <div class="admin-user-item">

                            <?php if(auth()->user()->image != NULL): ?>
                                <div class="image" style="background-image: url('<?php echo e(auth()->user()->image); ?>')"></div>
                            <?php else: ?>
                                <div class="image" style="background-image: url('<?php echo e(asset('images/man/01.jpg')); ?>')"></div>
                            <?php endif; ?>

                            <h4><?php echo e(auth()->user()->firstname." ".auth()->user()->lastname); ?></h4>
                            <p class="user-role"><?php echo e(auth()->user()->email); ?></p>

                        </div>

                        <div class="admin-user-action text-center">

                            <a class="btn btn-primary btn-sm" href="javascript:void()" onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();"><i class="fa fa-door-open"></i> Logout</a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>

                        </div>

                        <ul class="admin-user-menu clearfix">
                            <li>
                                <a href="<?php echo e(route('user.profile')); ?>"><i class="fa fa-user"></i> Profile</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('user.orders')); ?>"><i class="fa fa-list"></i> My Orders</a>
                            </li>
                            <li class="active">
                                <a href="<?php echo e(route('user.address.book')); ?>"><i class="fa fa-book"></i> Address Book</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('user.vendor.favourite')); ?>"><i class="fa fa-heart"></i> Favourite Vendors</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('user.password.change')); ?>"><i class="fa fa-key"></i> Change Password</a>
                            </li>

                        </ul>

                    </div>

                </div>

                <div class="GridLex-col-9_sm-8_xs-12">

                    <div class="admin-content-wrapper">

                        <div class="admin-section-title">

                            <h2>Address Book</h2>

                        </div>

                            <div class="row ">

                                <h4><a href="javascript:void()" data-href="<?php echo e(route('user.address')); ?>" id="addAddressBtn" style="font-size: 12px;"><i class="fa fa-pen"></i> Add to address book</a></h4><br><br>

                                    <div class="row">
                                        <input type="hidden" id="addressHidden" value="<?php if($defaultAddress != null): ?><?php echo e($defaultAddress->id); ?><?php endif; ?>">
                                        <?php if($defaultAddress != null): ?>
                                            <div class="col-md-4">
                                                <div data-id="<?php echo e($defaultAddress->id); ?>" class="card shadow-sm addressDiv addressDivActive" >
                                                    <div class="card-body">
                                                        <div class="defaultAddress">Default</div>
                                                        <div class="activeAddressTag siteColor"><i class="fa fa-check-circle"></i></div>
                                                        <small><?php echo e($defaultAddress->address); ?></small><br>
                                                        <small><?php echo e(auth()->user()->phone); ?></small><br>
                                                        <?php if(($defaultAddress->phone != NULL)): ?>
                                                            <small><?php echo e($defaultAddress->phone); ?></small><br>
                                                        <?php endif; ?>
                                                        <span><?php echo e($defaultAddress->lga." (".$defaultAddress->state.")"); ?></span>
                                                        <div class="addressAction">
                                                            <a href="javascript:void()" id="editAddress" data-href="<?php echo e(route('user.address.edit.form', ['id'=>$defaultAddress->id])); ?>"><i class="fa fa-pen"></i> Edit</a>
                                                            <a href="javascript:void()" id="deleteAddress" data-href="<?php echo e(route('user.address.delete', ['id'=>$defaultAddress->id])); ?>"><i class="fa fa-trash"></i> Delete</a>
                                                        </div>
                                                    </div>
                                                </div><br>
                                            </div>
                                        <?php endif; ?>
                                        <?php if($addresses->count() >= 1): ?>
                                            <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-md-4">
                                                    <div data-id="<?php echo e($address->id); ?>" class="card shadow-sm addressDiv" >
                                                        <div class="card-body">
                                                            <div class="activeAddressTag siteColor"><i class="fa fa-check-circle"></i></div>
                                                            <small><?php echo e($address->address); ?></small><br>
                                                            <small><?php echo e(auth()->user()->phone); ?></small><br>
                                                            <?php if($address->phone != NULL): ?>
                                                                <small><?php echo e($address->phone); ?></small><br>
                                                            <?php endif; ?>
                                                            <span><?php echo e($address->lga." (".$address->state.")"); ?></span>
                                                            <div class="addressAction">
                                                                <a href="javascript:void()" id="makeDefaultAddress" data-href="<?php echo e(route('user.address.default', ['id'=>$address->id])); ?>">Default</a>
                                                                <a href="javascript:void()" id="editAddress" data-href="<?php echo e(route('user.address.edit.form', ['id'=>$address->id])); ?>"><i class="fa fa-pen"></i> Edit</a>
                                                                <a href="javascript:void()" id="deleteAddress" data-href="<?php echo e(route('user.address.delete', ['id'=>$address->id])); ?>"><i class="fa fa-trash"></i> Delete</a>
                                                            </div>
                                                        </div>
                                                    </div><br>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>

                            </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coreui\resources\views/user/pages/address.blade.php ENDPATH**/ ?>