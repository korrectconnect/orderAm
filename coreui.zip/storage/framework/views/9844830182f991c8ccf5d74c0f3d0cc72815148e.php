
<div class="card-header">
    <strong>
        Today's Transactions
    </strong>
</div>

<div class="card-body">
    <?php if($orders->count() >= 1): ?>
    <div class="row">
        <div class="col-md-3">
            <div style="float: left; display:inline-block">
                <span>Todays Balance :</span><br>
                <?php if($total > 0): ?>
                <span class="text-success" style="font-size: 32px;">&#8358;<?php echo e($total); ?></span>
                <?php else: ?>
                <span class="text-danger" style="font-size: 32px;">&#8358;<?php echo e($total); ?></span>
                <?php endif; ?>
            </div>
        </div>

        <div class="col-md-3">
            <div style="float: left; display:inline-block">
                <span>Commission :</span><br>
                <span class="text-danger" style="font-size: 32px;">&#8358;<?php echo e($commission); ?></span>
            </div>
        </div>

        <div class="col-md-3">
            <div style="float: left; display:inline-block">
                <span>Real Profit :</span><br>
                <?php if($profit > 0): ?>
                <span class="text-success" style="font-size: 32px;">&#8358;<?php echo e($profit); ?></span>
                <?php else: ?>
                <span class="text-danger" style="font-size: 32px;">&#8358;<?php echo e($profit); ?></span>
                <?php endif; ?>
            </div>
        </div>

        <div class="col-md-3">
            <div style="float: left; display:inline-block">
                <span>Total Order :</span><br>
                <span style="font-size: 32px;"><?php echo e($orders->count()); ?></span>
            </div>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th><i class="fa fa-clock"></i></th>
                    <th>Order no.</th>
                    <th>Payment Mode</th>
                    <th>Total</th>
                    <th>Commission</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>

            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($order->updated_at); ?></td>
                    <td><?php echo e($order->order_no); ?></td>
                    <td><?php echo e($order->payment_mode); ?></td>
                    <td>&#8358;<?php echo e($order->total); ?></td>
                    <td><?php echo e($order->commission); ?>% (&#8358;<?php echo e(($order->total * $order->commission)/100); ?>)</td>
                    <td><a data-href="<?php echo e(route('vendor.ajax.order', ['order_no' => $order->order_no])); ?>" href="javascript:void()" id="view_order">View</a></td>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
    <?php else: ?>
        <center>
            <p><i class="fa fa-list"></i>&nbsp; No order here</p>
        </center>
    <?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\coreui\resources\views/vendor/pages/ajax/transaction_today.blade.php ENDPATH**/ ?>