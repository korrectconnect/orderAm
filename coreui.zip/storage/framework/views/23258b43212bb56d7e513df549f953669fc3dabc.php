<li class="c-sidebar-nav-item">
    <a class="c-sidebar-nav-link" href="">
        <i class="fa fa-pencil"></i> &nbsp; &nbsp;
        Dashboard
    </a>
</li>

<li class="c-sidebar-nav-dropdown">
    <a class="c-sidebar-nav-dropdown-toggle" href="#">
        <i class="fa fa-pencil"></i> &nbsp; &nbsp;
        Vendor
    </a>

        <div class="c-sidebar-nav-dropdown-items">
            <a class="dropdown-item" href="#">
                <i class="fa fa-pencil"></i> &nbsp; &nbsp;
                Add
            </a>
            <a class="dropdown-item" href="#">
                <i class="fa fa-pencil"></i> &nbsp; &nbsp;
                View All
            </a>
        </div>

</li>

<li class="c-sidebar-nav-dropdown">
    <a class="c-sidebar-nav-dropdown-toggle" href="#">
        <i class="fa fa-pencil"></i> &nbsp; &nbsp;
        Menu
    </a>

    <div class="c-sidebar-nav-dropdown-items">
        <a class="dropdown-item" href="#">
            <i class="fa fa-pencil"></i> &nbsp; &nbsp;
            Add
        </a>
        <a class="dropdown-item" href="#">
            <i class="fa fa-pencil"></i> &nbsp; &nbsp;
            View All
        </a>
    </div>

</li>

<li class="c-sidebar-nav-item">
    <a class="c-sidebar-nav-link" href="">
        <i class="fa fa-pencil"></i> &nbsp; &nbsp;
        Orders
    </a>
</li>

<li class="c-sidebar-nav-item">
    <a class="c-sidebar-nav-link" href="">
        <i class="fa fa-pencil"></i> &nbsp; &nbsp;
        Transactions
    </a>
</li>

<li class="c-sidebar-nav-item">
    <a class="c-sidebar-nav-link" href="">
        <i class="fa fa-pencil"></i> &nbsp; &nbsp;
        Customers
    </a>
</li>

<li class="c-sidebar-nav-item">
    <a class="c-sidebar-nav-link" href="">
        <i class="fa fa-pencil"></i> &nbsp; &nbsp;
        Settings
    </a>
</li>




<?php /**PATH C:\xampp\htdocs\coreui\resources\views/dashboard/shared/sidebar.blade.php ENDPATH**/ ?>