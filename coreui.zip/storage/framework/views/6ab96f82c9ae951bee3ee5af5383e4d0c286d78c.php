<div class="GridLex-col-3_sm-4_xs-12">

    <div class="admin-sidebar">

        <div class="admin-user-item">

            <div class="image" style="background-image: url('<?php echo e($vendor->image); ?>')"></div>

            <h4><?php echo e($vendor->name); ?></h4>
            <p class="user-role"><?php echo e($vendor->state." . ".$vendor->lga." . ".$vendor->area); ?></p>

            <?php if($auth == true): ?>
                <a href="javascript:void()" class="btn btn-sm btn-primary">VENDOR ADMIN ACTIVE</a>
            <?php endif; ?>

        </div>

        <ul class="admin-user-menu clearfix">
            <li>
                <a href="<?php echo e(route('vendor.dashboard')); ?>"><i class="fa fa-list"></i> Orders</a>
            </li>
            <li>
                <a href="<?php echo e(route('vendor.menus')); ?>"><i class="fa fa-hamburger"></i> Menus</a>
            </li>
            <li>
                <a href="<?php echo e(route('vendor.profile')); ?>"><i class="fa fa-user"></i> Profile</a>
            </li>
            <?php if($auth == true): ?>
                <li>
                    <a href="<?php echo e(route('vendor.finances')); ?>"><i class="fa fa-chart-line"></i> Finances</a>
                </li>
            <?php endif; ?>
            <?php if($auth == true): ?>
                <li>
                    <a href="<?php echo e(route('vendor.password')); ?>"><i class="fa fa-lock"></i> Password</a>
                </li>
            <?php endif; ?>
            
            <li>
                <a href="<?php echo e(route('vendor.authAdmin')); ?>"><i class="fa fa-key"></i> Authenticate Admin</a>
            </li>

        </ul>

    </div>

</div>
<?php /**PATH C:\xampp\htdocs\coreui\resources\views/vendor/inc/menu.blade.php ENDPATH**/ ?>