<?php $__env->startSection('content'); ?>

    <div class="admin-container-wrapper">

        <div class="container">

            <div class="GridLex-gap-15-wrappper">

                <div class="GridLex-grid-noGutter-equalHeight">

                    <?php echo $__env->make('vendor.inc.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div class="GridLex-col-9_sm-8_xs-12">

                        <div class="admin-content-wrapper">

                            <h2>Menu List</h2>

                            <!-- <?php echo e(route('vendor.ajax.orders', ['status' => 0, 'cancelled' => 0])); ?> -->
                            <div class="row">
                                <div class="col-md-9">
                                    <div class="alert alert-secondary">
                                        <?php if($menu_categories->count() >= 1): ?>
                                            <?php $__currentLoopData = $menu_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="menuCategoryBtn" id="menuCategoryBtn_<?php echo e($menu_category->id); ?>" data-href="<?php echo e(route('vendor.menu_list', ['category' => $menu_category->category])); ?>">
                                                    <?php echo e($menu_category->category); ?>

                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <div class="menuCategoryBtn" style="margin-left: 30px !important;" id="menuCategoryBtn_unsorted" data-href="<?php echo e(route('vendor.menu_list', ['category' => 'NULL'])); ?>">
                                                Unsorted
                                            </div>
                                        <?php else: ?>
                                                <small>No menu category added yet</small>
                                        <?php endif; ?>
                                    </div>

                                    <div class="card shadow-sm menuListDiv">

                                        <center><i class='fa fa-spin fa-circle-notch fa-2x'></i></center>

                                    </div><br>
                                </div>

                                <div class="col-md-3">
                                    <?php if($auth == true): ?>
                                        <a href="javascript:void()" id="addMenuBtn" data-href="<?php echo e(route('vendor.menu.add')); ?>"><i class="fa fa-plus-circle"></i> Add Menu</a><br>
                                        <a href="javascript:void()" id="addMenuCategoryBtn" data-href="<?php echo e(route('vendor.menu_category.add')); ?>"><i class="fa fa-plus-circle"></i> Add Menu Category</a><br><br>
                                        <div class="alert alert-secondary">
                                            <h3>Menu Categories</h3>
                                            <?php if($menu_categories->count() >= 1): ?>
                                                <?php $__currentLoopData = $menu_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div style="font-size: 12px;"><?php echo e($menu_category->category); ?> &nbsp;
                                                        <a href="javascript:void()" id="editMenuCategoryBtn" data-href="<?php echo e(route('vendor.menu_category.edit.form', ['id' => $menu_category->id])); ?>">Edit</a>/
                                                        <a href="javascript:void()" id="deleteMenuCategoryBtn" data-href="<?php echo e(route('vendor.menu_category.delete', ['id' => $menu_category->id])); ?>">Delete</a></div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                    <small>No menu category added yet</small>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coreui\resources\views/vendor/pages/menus.blade.php ENDPATH**/ ?>