<?php $__env->startSection('content'); ?>


<!-- start hero-header -->
<div class="breadcrumb-wrapper">

    <div class="container">

        <ol class="breadcrumb-list booking-step">
            <li><a href="#">Home</a></li>
            <li><span>Vendors</span></li>
            <li> &nbsp; / &nbsp;<span><?php echo e($type); ?></span></li>
        </ol>

    </div>

</div>
<!-- end hero-header -->

<div class="section sm">

    <div class="container">

        <div class="sorting-wrappper alt">

            <div class="GridLex-grid-middle">

                <div class="GridLex-col-3_sm-12_xs-12">

                    <div class="sorting-header">
                        <h3 class="sorting-title">
                            <?php if($vendors->count() >= 1): ?>
                                <?php echo e($vendors->count()); ?> &nbsp;<?php echo e($type); ?>

                            <?php endif; ?>
                        </h3>
                    </div>

                </div>



                <div class="GridLex-col-4_sm-6_xs-6_xss-12">

                    <div class="alert alert-secondary">

                        <span style="font-size:14px; color:rgb(255, 136, 0);">
                            <i class="fa fa-location-arrow"></i> Delivering to
                        </span> &nbsp; &nbsp;
                        <span style="font-size:14px; font-weight:bold;">
                            <?php echo e($state." , ".$area); ?>

                        </span>

                        <a href="" style="float: right; color:rgb(255, 136, 0);"><i class="fa fa-pen"></i></a>

                    </div>

                </div>

            </div>

        </div>

        <div class="company-grid-wrapper top-company-2-wrapper">

            <div class="GridLex-gap-30">

                <div class="GridLex-grid-noGutter-equalHeight">

                    <?php if($vendors->count() >= 1): ?>

                        <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="GridLex-col-3_sm-4_xs-6_xss-12">

                            <div class="top-company-2">
                                <a href="<?php echo e(route('user.vendor', ['id' => $vendor->id, 'name' => $type])); ?>">

                                    <div class="image">
                                        <img src="<?php echo e($vendor->image); ?>" alt="image" />
                                    </div>

                                    <div class="content">
                                        <h5 class="heading text-primary font700"><?php echo e($vendor->name); ?></h5>
                                        <p class="texting font600"><?php echo e($vendor->description); ?></p>
                                        <p class="mata-p clearfix"><span class="text-primary font700">&#8358; <?php echo e($vendor->price); ?></span> <span class="font13">min order</span> <span class="pull-right icon"><i class="fa fa-long-arrow-right"></i></span></p>

                                    </div>


                                </a>

                            </div>

                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php else: ?>

                        <h2>Opps No <?php echo e($type); ?> here !</h2><br><br>

                    <?php endif; ?>

                </div>

            </div>

        </div>

        

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coreui\resources\views/user/pages/vendors.blade.php ENDPATH**/ ?>