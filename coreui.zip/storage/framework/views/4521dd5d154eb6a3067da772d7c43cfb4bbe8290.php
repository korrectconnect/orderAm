<h3>Order Summary</h3>
<div class="myscrollW" style="width: auto; height:auto; max-height:100px; overflow:auto; margin-bottom:15px;">

    <?php if($carts->count() >= 1): ?>
        <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="order-summary-list">
                <span class="cart-product-name"><?php echo e($cart->name); ?></span> &nbsp; &nbsp;
                <span>Qty: <b><?php echo e($cart->quantity); ?></b></span>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="cart-amount">
            Order Amount : <span>&#8358 <?php echo e($order_total); ?> </span>
        </div>
        <div class="cart-amount">
            Delivery Charge : <span>&#8358 <?php echo e($vendor->delivery_charge); ?></span>
        </div>
        <div class="cart-amount">
            Tax : <span>&#8358 <?php echo e($vendor->vendor_charge + $vendor->tax); ?></span>
        </div>
        <?php if($coupon != NULL): ?>
        <div class="cart-amount" style="color: rgb(0, 200, 0);" >
            Coupon : <span>&#8358 -<?php echo e($coupon->amount); ?> </span>
        </div>
        <?php endif; ?>
    <?php endif; ?>

</div>

<div class="myscrollW" style="width: auto; height:auto; max-height:150px; overflow:auto; margin-bottom:15px;">
    <div class="siteColor" style="font-size:15px; margin-bottom:4px; font-weight:bold;"><i class="fa fa-location-arrow"></i> Deliver to</div>
    <div style="font-size: 12px;">
        <?php echo e($address->address); ?><br>
        <?php echo e($address->lga." (".$address->state.")"); ?><br>
        <?php if($address->description !== NULL): ?>)
            <small>(<?php echo e($address->description); ?>)</small><br>
        <?php endif; ?>
    </div>
</div>

<div>
    <?php if($type == "card"): ?>
        Pay Online(PayStack) <i class="fa fa-credit-card"></i>
    <?php else: ?>
        Pay on delivery <i class="fa fa-handshake"></i>
    <?php endif; ?>

    <?php if($coupon != NULL): ?>
        <b class="f-r">Coupon : <?php echo e($coupon->code); ?> </b>
    <?php endif; ?>
</div><br>

<div>
    <form action="<?php echo e(route('user.order.place')); ?>" method="POST" id="placeOrderForm">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="address" id="placeOrderAddress" value="<?php echo e($address->id); ?>">
        <input type="hidden" name="vendor" id="placeOrderVendor" value="<?php echo e($vendor->id); ?>">
        <?php if($coupon != NULL): ?>
            <input type="hidden" name="coupon" id="placeOrderCoupon" value="<?php echo e($coupon->code); ?>">
        <?php else: ?>
            <input type="hidden" name="coupon" id="placeOrderCoupon" value="<?php echo e($coupon); ?>">
        <?php endif; ?>
        <input type="hidden" name="payment_type" id="placeOrderPaymentType" value="<?php echo e($type); ?>">
        <input type="hidden" name="transaction" id="placeOrderTransactionId" value="">
    </form>

    <b class="f-l">Total: &#8358;<?php echo e($total); ?></b>
    <?php if($type == "cash"): ?>
        <button class="btn btn-sm btn-primary" id="btncCashPlaceOrder" style="float: right;">Place Order</button>
    <?php else: ?>
        <button class="btn btn-sm btn-primary" id="btnCardPlaceOrder" style="float: right;">Place Order</button>
    <?php endif; ?>
</div>

<script>
    $('#btncCashPlaceOrder').click(function() {
            $("#btncCashPlaceOrder").prop('disabled', true);
            $("#placeOrderForm").submit();
    });

    $('#btnCardPlaceOrder').click(function() {
        $("#btnCardPlaceOrder").prop('disabled', true);
        alert("Payment Gateway API is called");
    });
</script>
<?php /**PATH C:\xampp\htdocs\coreui\resources\views/user/ajax/order_summary.blade.php ENDPATH**/ ?>