<?php $__env->startSection('content'); ?>

<div class="row null" >

<div class="col-md-6">
    <div class="card">
      <div class="card-header"><i class="fa fa-align-justify"></i> <b><?php echo e($vendor->name." . ".$vendor->lga); ?></b></div>
      <div class="card-body">

        <div class="vendor-image" style="background-image:url('<?php echo e($vendor->image); ?>');"></div>
        <div>
            <table class="table table-striped">
                <tbody>
                    <tr>
                        <td><b>Name</b></td>
                        <td><?php echo e($vendor->name); ?></td>
                    </tr>
                    <tr>
                        <td><b>Type</b></td>
                        <td><?php echo e($vendor->type); ?></td>
                    </tr>
                    <tr>
                        <td><b>Email</b></td>
                        <td><?php echo e($vendor->email); ?></td>
                    </tr>
                    <tr>
                        <td><b>Contact</b></td>
                        <td><?php echo e($vendor->contact); ?></td>
                    </tr>
                    <tr>
                        <td><b>Address</b></td>
                        <td><?php echo e($vendor->address); ?></td>
                    </tr>
                    <tr>
                        <td><b>LGA</b></td>
                        <td><?php echo e($vendor->lga); ?></td>
                    </tr>
                    <tr>
                        <td><b>Zip</b></td>
                        <td><?php echo e($vendor->zip); ?></td>
                    </tr>
                    <tr>
                        <td><b>State</b></td>
                        <td><?php echo e($vendor->state); ?></td>
                    </tr>
                    <tr>
                        <td><b>Country</b></td>
                        <td><?php echo e($vendor->country); ?></td>
                    </tr>
                    <tr>
                        <td><b>Status</b></td>
                        <td>
                            <?php if($vendor->status == 1): ?>
                                <span class="badge badge-success">Active</span>
                            <?php else: ?>
                                <span class="badge badge-danger">Suspended</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

      </div>
    </div>
</div>

<div class="col-md-6">
    <div class="card">
        <div class="card-header"><i class="fa fa-align-justify"></i> <b>Menu List</b>
            <a href="#" style="float:right;" id="add_menu_btn" data-toggle="modal" data-target="#AddMenuFormModal" data-id="<?php echo e($vendor->id); ?>">Add Menu</a>
        </div>
        <div class="card-body">
            <a href="javascript:void()" id="refreshMenuBtn" onclick="refreshMenu(<?php echo e($vendor->id); ?>, '../');">Refresh</a><br><br>
            <div style="width:100%; height:auto;" class="refreshMenuDiv card-overflow">
              <?php if($menus->count() >= 1): ?>
                  <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="menu-vendor-div">
                      <div class="row null">
                          <div class="col-sm-4">
                              
                              <img src="<?php echo e($menu->image); ?>" style="width:80px; height:80px; border-radius:10px;" alt="">
                          </div>
                          <div class="col-sm-8">
                              <div class="menu-vendor-txt">
                                  <b><?php echo e($menu->menu); ?></b><br>

                                  <span style="font-size:12px;">
                                      <?php echo e($menu->name); ?>

                                  </span><br>

                                  <small><?php echo e($menu->category." . ".$menu->description); ?></small><br>

                                  <div style="display:inline-block; float:right; font-size:13px; color:rgb(0, 0, 150); margin-top:-60px;">
                                       &#8358; <?php echo e($menu->price); ?>

                                  </div>

                                  <div style="display:inline-block; float:right; font-size:12px; margin-top:-20px;">
                                    <a href="javascript:void()" id="deleteMenu_<?php echo e($menu->id); ?>" data-id="<?php echo e($menu->id); ?>" data-link="<?php echo e(route('admin.menu.delete',['id' => $menu->id])); ?>" style="color:rgb(150, 0, 0);"><i class='fa fa-trash'></i> Delete</a>
                                    <script>
                                        $("#deleteMenu_<?php echo e($menu->id); ?>").click(function() {
                                            var link = $(this).data("link");
                                            $("#deleteMenu_<?php echo e($menu->id); ?>").html("<i class='fa fa-spin fa-spinner'></i>");

                                            deleteMenu(link);
                                        });
                                    </script>
                                </div>
                              </div>
                          </div>
                      </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
              <div style="font-size: 14px; width: 100%; height:auto; text-align:center; padding-top:13px;" >No Menu Added<br><p><a href="javascript:void()" id="add_menu_btn" data-toggle="modal" data-target="#AddMenuFormModal" data-id="<?php echo e($vendor->id); ?>">Add Menu</a></p></div>
              <?php endif; ?>
            </div>
          </div>
        </div>
</div>

</div>

<?php if($categories->count() >= 1): ?>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script>
            appendMenuCategory("<?php echo e($category->category); ?>");
        </script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<script>
    $("#add_menu_btn").click(function() {
        $(".modal-title").html("<?php echo e($vendor->name); ?> &nbsp; &nbsp; <span style='font-size:12px;'><?php echo e($vendor->type.' . '.$vendor->lga); ?></span>");
        //$(".modal-body").html("<center><i class='fa fa-spinner fa-2x fa-spin'></i></center>");
        var id = $(this).data('id');
        $("#vendor_id").val(id);
        $("#menu_refresh_id").attr("data-id","<?php echo e($vendor->id); ?>");
    });
</script>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coreui\resources\views/admin/pages/vendor/single.blade.php ENDPATH**/ ?>