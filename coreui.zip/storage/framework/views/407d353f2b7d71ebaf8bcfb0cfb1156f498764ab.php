<?php if($riders->count() >= 1): ?>
    <?php $__currentLoopData = $riders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Location Assigned</th>
                    <th>Assigned Orders</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $riders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><?php echo e($rider->firstname); ?> <?php echo e($rider->lastname); ?></td>
                        <td>
                            <?php if($rider->location_assigned != NULL): ?>
                                <span class="text-primary"><?php echo e($rider->location_assigned); ?></span>
                            <?php else: ?>
                                <span class="text-danger">Unassigned</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($rider->order_no); ?></td>
                        <td>
                            <?php if($rider->active == NULL || $rider->active == 0): ?>
                                <span class="badge badge-danger">Inactive</span>
                            <?php else: ?>
                                <span class="badge badge-success">Active</span>
                            <?php endif; ?>
                        </td>
                        <td><a href="javascript:void()" data-href="<?php echo e(route('admin.order.confirm', ['id' => $rider->id, 'order' => $order->id])); ?>" id="confirmAssignOrderBtn">Assign Order</a></td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <div class="alert alert-warning">
        No Rider has been assigned to vendors location<br><br>
        <b>City : <?php echo e($order->state); ?><br>
        Lga : <?php echo e($order->lga); ?></b>
    </div><br>

    <b>Select rider from other areas in <?php echo e($order->state); ?></b>
    <div class="alert alert-secondary">

        <?php if($other_riders->count() >= 1): ?>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Location Assigned</th>
                            <th>Assigned Orders</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $other_riders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other_rider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td><?php echo e($other_rider->firstname); ?> <?php echo e($other_rider->lastname); ?></td>
                                <td>
                                    <?php if($other_rider->location_assigned != NULL): ?>
                                        <span class="text-primary"><?php echo e($other_rider->location_assigned); ?></span>
                                    <?php else: ?>
                                        <span class="text-danger">Unassigned</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($other_rider->order_no); ?></td>
                                <td>
                                    <?php if($other_rider->active == NULL || $other_rider->active == 0): ?>
                                        <span class="badge badge-danger">Inactive</span>
                                    <?php else: ?>
                                        <span class="badge badge-success">Active</span>
                                    <?php endif; ?>
                                </td>
                                <td><a href="javascript:void()" data-href="<?php echo e(route('admin.order.confirm', ['id' => $other_rider->id, 'order' => $order->id])); ?>" id="confirmAssignOrderBtn">Assign Order</a></td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-warning">There are no registered riders in <b><?php echo e($order->state); ?></b></div>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\coreui\resources\views/admin/pages/ajax/order_assign.blade.php ENDPATH**/ ?>