<h3>Order Summary</h3>
<div class="myscrollW" style="width: auto; height:auto; max-height:100px; overflow:auto; margin-bottom:15px;">

    <?php if($order_items->count() >= 1): ?>
        <?php $__currentLoopData = $order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="order-summary-list">
                <span class="cart-product-name">
                    <div style="margin-left: -10px; margin-top:-17px; margin-right:10px; color:#fff; padding:3px 6px 2px 6px; background-color:rgb(31, 143, 106); display: inline-block; "><i class="fa fa-hamburger"></i></div>
                     <?php echo e($order_item->name); ?></span> &nbsp; &nbsp;
                <span>Qty: <b><?php echo e($order_item->quantity); ?></b></span>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="cart-amount">
            Order Amount : <span>&#8358 <?php echo e($order->total - $vendor->delivery_charge - ($vendor->vendor_charge + $vendor->tax)); ?> </span>
        </div>
        <div class="cart-amount">
            Delivery Charge : <span>&#8358 <?php echo e($vendor->delivery_charge); ?></span>
        </div>
        <div class="cart-amount">
            Tax : <span>&#8358 <?php echo e($vendor->vendor_charge + $vendor->tax); ?></span>
        </div>
        <?php if($coupon != NULL): ?>
        <div class="cart-amount" style="color: rgb(0, 200, 0);" >
            Coupon : <span>&#8358 -<?php echo e($coupon->amount); ?> </span>
        </div>
        <?php endif; ?>
    <?php endif; ?>

</div>

<div class="myscrollW" style="width: auto; height:auto; max-height:150px; overflow:auto; margin-bottom:15px;">
    <div class="siteColor" style="font-size:15px; margin-bottom:4px; font-weight:bold;"><i class="fa fa-location-arrow"></i> Deliver to</div>
    <div style="font-size: 12px;">
        <?php echo e($user->firstname." ".$user->lastname); ?><br>
        <?php echo e($address->address); ?><br>
        <?php echo e($address->lga." (".$address->state.")"); ?><br>
        <?php if($address->description !== NULL): ?>
            <small>(<?php echo e($address->description); ?>)</small><br>
        <?php endif; ?>
    </div>
</div>

<div>
    <?php if($order->payment_mode == "card"): ?>
        Pay Online(PayStack) <i class="fa fa-credit-card"></i>
    <?php else: ?>
        Pay on delivery <i class="fa fa-handshake"></i>
    <?php endif; ?>

    <?php if($coupon != NULL): ?>
        <b class="f-r">Coupon : <?php echo e($coupon->code); ?> </b>
    <?php endif; ?>
</div>
<div style="font-size: 12px; margin: 5px 0px 5px 0px; font-weight:bold;">Delivery time :
    <?php if($order->delivery_time == NULL): ?>
        <span class="text-danger">As soon as possible</span>
    <?php else: ?>
        <span class="text-success"><?php echo e($order->delivery_time); ?></span>
    <?php endif; ?>
</div>

<div>

    <b class="f-l">Total: &#8358;<?php echo e($order->total); ?></b>
    <?php if($order->status == 0 && $order->cancelled == 0): ?>
        <div class="f-r" style="display:inline-block;">
            <button class="btn btn-xs btn-success" id="confirmOrderBtn" data-href="<?php echo e(route('vendor.order.confirm', ['order_no' => $order->order_no])); ?>">Confirm</button>
            <button class="btn btn-xs btn-danger" id="declineOrderBtn" data-href="<?php echo e(route('vendor.order.decline', ['order_no' => $order->order_no])); ?>">Decline</button>
        </div>
    <?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\coreui\resources\views/vendor/pages/ajax/order.blade.php ENDPATH**/ ?>