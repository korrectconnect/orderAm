<?php $__env->startSection('content'); ?>

<!-- start hero-header -->
<div class="breadcrumb-wrapper">

    <div class="container">

        <ol class="breadcrumb-list booking-step">
            <li><a href="#">Home</a></li>
            <li><span>Vendors</span></li>
        </ol>

    </div>

</div>
<!-- end hero-header -->

<div class="section sm">

    <div class="container">

        <div class="container">

            <h2 style="color: #000000">Select vendor location, lets browse&nbsp; <i class="fa fa-smile" aria-hidden="true"></i></h2>

            <div style="font-size:18px; color:rgb(255, 136, 0); margin-bottom:10px;">
                <i class="fa fa-location-arrow"></i> Delivering to
            </div>
            <form action="" method="POST" id="vendorLocationForm">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="state">&nbsp; <b>City</b></label>
                            <select name="state" id="state" class="form-control" style="font-weight: bold;">
                                <?php if($states->count() >= 1): ?>
                                    <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option><?php echo e($state->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="area">&nbsp; <b>Area</b></label>
                            <select name="area" id="area" class="form-control" style="font-weight: bold;">
                                <?php if($lgas->count() >= 1): ?>
                                    <?php $__currentLoopData = $lgas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option><?php echo e($lga->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                </div>
            </form>

            <h4><b>Select Service</b></h4><br>
            <input type="hidden" id="loadVendorByLocation" value="">

            <div class="vendor_service">
                <div class="row">
                    <?php if($categories->count() >= 1): ?>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3">
                                <div class="card shadow-sm rounded" id="selectServiceBtn" data-load="<?php echo e($category->name); ?>">
                                    <div class="card-body">
                                        <img src="<?php echo e($category->image); ?>" alt="<?php echo e($category->name); ?>" style="width: 50px;"><br>
                                        <span style="color:rgb(255, 136, 0);"><b><?php echo e($category->name); ?></b></span><br>
                                        <small><?php echo e($category->description); ?></small>
                                    </div>
                                </div><br>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coreui\resources\views/user/pages/vendors_home.blade.php ENDPATH**/ ?>