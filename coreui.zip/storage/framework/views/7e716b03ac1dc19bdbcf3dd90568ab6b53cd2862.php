
<?php if($menus->count() >= 1): ?>

<form action="" method="POST" id="addToCartForm">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="menu_id" value="" id="inputCartMenuID">
    <input type="hidden" name="vendor_id" value="<?php echo e($vendor_id); ?>" id="inputCartVendorID">
</form>

    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="row menuListWrap">
            <div class="col-sm-3">
                <div class="menuListImage" style="background-image:url('<?php echo e($menu->image); ?>');"></div>
            </div>
            <div class="col-sm-9">
                <span class="siteColor"><b><?php echo e($menu->menu); ?></b></span><br>
                <small><?php echo e($menu->description); ?></small><br>
                <span class="text-success"><b>&#8358; <?php echo e($menu->price); ?></b></span>
                <?php if($menu->stock == 1): ?>
                    <div class="addToCartBtn" id="cart_btn_<?php echo e($menu->id); ?>" data-menu="<?php echo e($menu->id); ?>"><i class="fa fa-plus"></i> Add <i class="fa fa-shopping-cart"></i></div>
                <?php else: ?>
                    <div class="outOfStockBtn">Out of stock</div>
                <?php endif; ?>
            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php else: ?>
    Oops No Menu here
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\coreui\resources\views/user/ajax/menu_list.blade.php ENDPATH**/ ?>