<?php if($locations->count() >= 1): ?>
                            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="alert alert-secondary">
                                    <i class="fa fa-location-arrow fa-2x"></i> &nbsp; <?php echo e($location->type." : ".$location->name); ?>

                                    <button class="btn btn-sm btn-link" id="deleteVendorLocationBtn" data-id="<?php echo e($location->id); ?>" style="margin-top:0px; float:right;"><i class="fa fa-trash fa-1x text-danger"></i></button>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="alert alert-danger">
                                <small>You have not added any location for vendors <i class="fa fa-exclamation"></i></small>
                            </div>
                        <?php endif; ?>
<?php /**PATH C:\xampp\htdocs\coreui\resources\views/admin/pages/ajax/vendor_location.blade.php ENDPATH**/ ?>