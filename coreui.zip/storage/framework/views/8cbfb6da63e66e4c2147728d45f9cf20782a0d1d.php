<h3>Order Summary</h3>
<div class="myscrollW" style="width: auto; height:auto; max-height:100px; overflow:auto; margin-bottom:15px;">

    <?php if($order_items->count() >= 1): ?>
        <?php $__currentLoopData = $order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="order-summary-list">
                <span class="cart-product-name"><?php echo e($order_item->name); ?></span> &nbsp; &nbsp;
                <span>Qty: <b><?php echo e($order_item->quantity); ?></b></span>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="cart-amount">
            Order Amount : <span>&#8358 <?php echo e($order->total - $vendor->delivery_charge - ($vendor->vendor_charge + $vendor->tax)); ?> </span>
        </div>
        <div class="cart-amount">
            Delivery Charge : <span>&#8358 <?php echo e($vendor->delivery_charge); ?></span>
        </div>
        <div class="cart-amount">
            Tax : <span>&#8358 <?php echo e($vendor->vendor_charge + $vendor->tax); ?></span>
        </div>
        <?php if($coupon != NULL): ?>
        <div class="cart-amount" style="color: rgb(0, 200, 0);" >
            Coupon : <span>&#8358 -<?php echo e($coupon->amount); ?> </span>
        </div>
        <?php endif; ?>
    <?php endif; ?>

</div>

<div class="myscrollW" style="width: auto; height:auto; max-height:150px; overflow:auto; margin-bottom:15px;">
    <div class="siteColor" style="font-size:15px; margin-bottom:4px; font-weight:bold;"><i class="fa fa-location-arrow"></i> Deliver to</div>
    <div style="font-size: 12px;">
        <?php echo e(auth()->user()->firstname." ".auth()->user()->lastname); ?><br>
        <?php echo e($address->address); ?><br>
        <?php echo e($address->lga." (".$address->state.")"); ?><br>
        <?php if($address->description !== NULL): ?>
            <small>(<?php echo e($address->description); ?>)</small><br>
        <?php endif; ?>
    </div>
</div>

<div>
    <?php if($order->payment_mode == "card"): ?>
        Pay Online(PayStack) <i class="fa fa-credit-card"></i>
    <?php else: ?>
        Pay on delivery <i class="fa fa-handshake"></i>
    <?php endif; ?>

    <?php if($coupon != NULL): ?>
        <b class="f-r">Coupon : <?php echo e($coupon->code); ?> </b>
    <?php endif; ?>
</div><br>

<div>

    <b class="f-r">Total: &#8358;<?php echo e($order->total); ?></b>

</div>
<?php /**PATH C:\xampp\htdocs\coreui\resources\views/user/ajax/myorder_summary.blade.php ENDPATH**/ ?>