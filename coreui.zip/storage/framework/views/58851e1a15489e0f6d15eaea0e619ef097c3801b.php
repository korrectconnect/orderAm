<?php $__env->startSection('content'); ?>


    <!-- start hero-header -->
			<div class="breadcrumb-wrapper">

				<div class="container">

					<ol class="breadcrumb-list booking-step">
						<li><a href="index.html">Home</a></li>
                        <li><span>Order</span></li>
                        <li><span> &nbsp; / &nbsp; Cart</span></li>
					</ol>

				</div>

			</div>
			<!-- end hero-header -->

			<div class="section sm">

				<!-- Content Start -->
				<!-- Start order-online-->
				<div id="order-process">
					<div class="container">



						<div class="order-inner-content">
							<div class="row">
								<div class="col-md-9">
                                    <h4><?php echo e($vendor->name); ?></h4>

                                    <div class="alert alert-secondary" style="margin-bottom: 30px;">

                                        <span style="font-size:14px; color:rgb(255, 136, 0);">
                                            <i class="fa fa-location-arrow"></i> Location
                                        </span> &nbsp; &nbsp;
                                        <span style="font-size:14px; font-weight:bold;">
                                            <?php echo e($vendor->state." , ".$vendor->lga); ?>

                                        </span>

                                    </div>

                                    <h4>Delivery Address &nbsp; <a href="javascript:void()" data-href="<?php echo e(route('user.address')); ?>" id="addAddressBtn" style="font-size: 12px;"><i class="fa fa-pen"></i> Add</a></h4>

                                    <div class="row">
                                        <input type="hidden" id="addressHidden" value="<?php if($defaultAddress != null): ?><?php echo e($defaultAddress->id); ?><?php endif; ?>">
                                        <?php if($defaultAddress != null): ?>
                                            <div class="col-md-4">
                                                <div data-id="<?php echo e($defaultAddress->id); ?>" class="card shadow-sm addressDiv addressDivActive" >
                                                    <div class="card-body">
                                                        <div class="defaultAddress">Default</div>
                                                        <div class="activeAddressTag siteColor"><i class="fa fa-check-circle"></i></div>
                                                        <small><?php echo e($defaultAddress->address); ?></small><br>
                                                        <small><?php echo e(auth()->user()->phone); ?></small><br>
                                                        <?php if(($defaultAddress->phone != NULL)): ?>
                                                            <small><?php echo e($defaultAddress->phone); ?></small><br>
                                                        <?php endif; ?>
                                                        <span><?php echo e($defaultAddress->lga." (".$defaultAddress->state.")"); ?></span>
                                                        <div class="addressAction">
                                                            <a href="javascript:void()" id="editAddress" data-href="<?php echo e(route('user.address.edit.form', ['id'=>$defaultAddress->id])); ?>"><i class="fa fa-pen"></i> Edit</a>
                                                            <a href="javascript:void()" id="deleteAddress" data-href="<?php echo e(route('user.address.delete', ['id'=>$defaultAddress->id])); ?>"><i class="fa fa-trash"></i> Delete</a>
                                                        </div>
                                                    </div>
                                                </div><br>
                                            </div>
                                        <?php endif; ?>
                                        <?php if($addresses->count() >= 1): ?>
                                            <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-md-4">
                                                    <div data-id="<?php echo e($address->id); ?>" class="card shadow-sm addressDiv" >
                                                        <div class="card-body">
                                                            <div class="activeAddressTag siteColor"><i class="fa fa-check-circle"></i></div>
                                                            <small><?php echo e($address->address); ?></small><br>
                                                            <small><?php echo e(auth()->user()->phone); ?></small><br>
                                                            <?php if($address->phone != NULL): ?>
                                                                <small><?php echo e($address->phone); ?></small><br>
                                                            <?php endif; ?>
                                                            <span><?php echo e($address->lga." (".$address->state.")"); ?></span>
                                                            <div class="addressAction">
                                                                <a href="javascript:void()" id="makeDefaultAddress" data-href="<?php echo e(route('user.address.default', ['id'=>$address->id])); ?>">Default</a>
                                                                <a href="javascript:void()" id="editAddress" data-href="<?php echo e(route('user.address.edit.form', ['id'=>$address->id])); ?>"><i class="fa fa-pen"></i> Edit</a>
                                                                <a href="javascript:void()" id="deleteAddress" data-href="<?php echo e(route('user.address.delete', ['id'=>$address->id])); ?>"><i class="fa fa-trash"></i> Delete</a>
                                                            </div>
                                                        </div>
                                                    </div><br>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>

                                    <h4>Payment Type</h4>

                                    <div class="row">
                                        <div class="col-sm-3"><input type="radio" name="pay" id="payOnDeviveryRadio" checked> Pay on delivery</div>
                                        <div class="col-sm-3"><input type="radio" name="pay" id="payOnlineRadio" > Pay online (PayStack)</div>
                                    </div><br><br>
								</div>
								<!-- Sidearea Starts -->
								<div class="col-md-3 col-xs-12">
									<!-- Spacer Starts -->
									<div class="spacer-1 medium hidden-lg hidden-md"></div>
									<!-- Spacer Ends -->
									<!-- Your Order Starts -->
									<div class="side-block-order border-radius-4">
										<!-- Heading Starts -->
										<h5 class="text-center"><i class="fa fa-shopping-basket"></i> Your Orders</h5>
										<!-- Heading Ends -->
										<!-- Order Content Starts -->
										<!-- Order Content Starts -->
                                        <div class="side-block-order-content">
                                            <!-- Order Item List Starts -->
                                            <div id="cart-div">
                                                <?php if(!auth()->user()): ?>
                                                    <div class="alert alert-secondary">
                                                        <small><b>Login to view cart</b></small>
                                                    </div>
                                                <?php else: ?>
                                                    <?php if($carts->count() >= 1): ?>
                                                        <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="clearfix cart-items">
                                                                <div class="pull-left">
                                                                <div class="update-product">
                                                                    <a title="Increase item quantity" href="javascript:void()" id="increase-cart-btn" data-id="<?php echo e($cart->id); ?>"><i class="fa fa-plus-circle"></i></a>
                                                                    <a title="Decrease item quantity" href="javascript:void()" id="decrease-cart-btn" data-id="<?php echo e($cart->id); ?>"><i class="fa fa-minus-circle"></i></a>
                                                                </div>
                                                                </div>
                                                                    <div class="cart-product-name pull-left"><?php echo e($cart->name); ?></div>
                                                                    <span class="cart-product-price pull-right text-spl-color pull-left">Qty: <?php echo e($cart->quantity); ?></span>
                                                                    <div class="cart-product-price pull-right text-spl-color f-r"><b>&#8358; <?php echo e($cart->price*$cart->quantity); ?></b></div>
                                                                    <div class="remove-cart-btn" ><a title="delete item from cart" id="remove-cart-btn" data-id="<?php echo e($cart->id); ?>" href="javascript:void()"><i class="fa fa-trash"></i></a></div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                        <div class="alert alert-secondary">
                                                            <small><b><i class="fa fa-shopping-cart"></i> cart for this vendor is empty</b></small>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <hr>

                                                <div class="cart-amount">
                                                    Order Amount : <span>&#8358
                                                        <?php if(auth()->user()): ?>
                                                            <?php if($carts->count() >= 1): ?>
                                                                <?php echo e($order_total); ?>

                                                            <?php else: ?>
                                                                0
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            0
                                                        <?php endif; ?>
                                                    </span>
                                                </div>
                                                <div class="cart-amount">
                                                    Delivery Charge : <span>&#8358
                                                        <?php if(auth()->user()): ?>
                                                            <?php if($carts->count() >= 1): ?>
                                                                <?php echo e($vendor->delivery_charge); ?>

                                                            <?php else: ?>
                                                                0
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            0
                                                        <?php endif; ?>
                                                    </span>
                                                </div>
                                                <div class="cart-amount">
                                                    Tax : <span>&#8358
                                                        <?php if(auth()->user()): ?>
                                                            <?php if($carts->count() >= 1): ?>
                                                                <?php echo e($vendor->vendor_charge + $vendor->tax); ?>

                                                            <?php else: ?>
                                                                0
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            0
                                                        <?php endif; ?>
                                                    </span>
                                                </div>

                                                <div class="cart-amount" id="couponDiv" >
                                                    Coupon : <span>&#8358 <span id="couponSpan"></span> </span>
                                                </div>
                                                <hr>

                                                <div class="cart-amount">
                                                    <b>Total</b> : <span>&#8358
                                                        <?php if(auth()->user()): ?>
                                                            <?php if($carts->count() >= 1): ?>
                                                                <span id="orderTotal"><?php echo e($total); ?></span>
                                                            <?php else: ?>
                                                                0
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            0
                                                        <?php endif; ?>
                                                    </span>
                                                </div>
                                                <input type="hidden" id="orderTotalHidden" value="<?php echo e($total); ?>">
                                                <input type="hidden" id="mCoupon" value="">
                                            </div>

                                            <form id="checkCouponForm">
                                                <div class="row">
                                                    <div class="col-sm-7">
                                                        <input type="text" class="form-control" name="coupon" id="orderCoupon" placeholder="Coupon Code">
                                                        <input type="hidden" name="vendor" value="<?php echo e($vendor->id); ?>">
                                                    </div>
                                                    <div class="col-sm-5">
                                                        <button type="submit" class="btn btn-sm btn-warning" id="couponCheckBtn">Update</button>
                                                    </div>
                                                </div><br>
                                            </form>
                                            <!-- Order Item Total Ends -->
                                            <div class="cfo-checkoutarea">
                                                <?php if(auth()->user()): ?>
                                                    <?php if($carts->count() >= 1): ?>
                                                        <button name="a" id="order-checkout-btn" data-vendor="<?php echo e($vendor->id); ?>" class="btn btn-primary btn-block custom-checkout">Proceed to Checkout</button>
                                                    <?php else: ?>
                                                        <button name="a" id="order-checkout-btn" data-vendor="<?php echo e($vendor->id); ?>" class="btn btn-primary btn-block custom-checkout" disabled="true">Proceed to Checkout</button>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <button name="a" id="order-checkout-btn" data-vendor="<?php echo e($vendor->id); ?>" class="btn btn-primary btn-block custom-checkout" disabled="true">Proceed to Checkout</button>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <!-- Order Content Ends -->
									</div>
									<!-- Your Order Ends -->
									<div id="ad-wrapper">

										<img class="img-responsive" src="<?php echo e(asset('images/add-banner/add-banner.png')); ?>" alt="">

									</div>
								</div>
								<!-- Sidearea Ends -->
							</div>
						</div>
					</div>
					<!--.container-->
				</div>
				<!--#order-online-->
				<!--end order-online-->
				<!-- Content End -->

			</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coreui\resources\views/user/pages/order.blade.php ENDPATH**/ ?>