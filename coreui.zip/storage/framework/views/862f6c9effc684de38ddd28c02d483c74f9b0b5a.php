<?php $__env->startSection('content'); ?>

<form data-href="<?php echo e(route('admin.vendor.edit')); ?>" enctype="multipart/form-data" id="editVendorForm" >
    <?php echo csrf_field(); ?>

    <input type="hidden" name="id" value="<?php echo e($vendor->id); ?>">

<div class="row" style="margin: 0px !important; padding: 0px !important;">

<div class="col-sm-6">
    <div class="card">
      <div class="card-header"><strong>Edit Vendors</strong></div>
      <div class="card-body">
        <div class="form-group">
          <label for="name">Name</label>
          <input name="name" class="form-control" id="name" type="text" value="<?php echo e($vendor->name); ?>">
        </div>
        <div class="form-group">
          <label for="email">Email</label>
          <input name="email" class="form-control" id="email" type="text" value="<?php echo e($vendor->email); ?>">
        </div>
        <div class="form-group">
            <label for="description">Short description</label>
            <input name="description" class="form-control" id="description" type="text" value="<?php echo e($vendor->description); ?>">
          </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="type">Type</label>
                    <select name="type" class="form-control" id="type">
                        <option value="<?php echo e($vendor->type); ?>"><?php echo e($vendor->type); ?></option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($category->name != $vendor->type): ?>
                                <option><?php echo e($category->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="tax">Tax</label>
                    <input name="tax" class="form-control" id="tax" type="text" value="<?php echo e($vendor->tax); ?>">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="delivery_charge">Delivery Charge</label>
                    <input name="delivery_charge" class="form-control" id="delivery_charge" type="text" value="<?php echo e($vendor->delivery_charge); ?>">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="vendor_charge">Vendor Charge</label>
                    <input name="vendor_charge" class="form-control" id="vendor_charge" type="text" value="<?php echo e($vendor->vendor_charge); ?>">
                </div>
            </div>
        </div>
          <div class="form-group">
            <label for="street">Contact Info</label>
            <input name="contact" class="form-control" id="street" type="text" value="<?php echo e($vendor->contact); ?>">
          </div>
        <div class="row">
            <div class="form-group col-sm-6">
                <label for="state">State</label>
                <select name="state" class="form-control" id="state">
                    <option value="<?php echo e($vendor->state); ?>"><?php echo e($vendor->state); ?></option>
                    <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($state->name != $vendor->state): ?>
                            <option><?php echo e($state->name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group col-sm-6">
                <label for="country">Country</label>
                <select name="country" class="form-control" id="country">
                   <option value="Nigeria">Nigeria</option>
                </select>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <label for="city">LGA</label>
                <select name="lga" class="form-control" id="lga">
                    <option value="<?php echo e($vendor->lga); ?>"><?php echo e($vendor->lga); ?></option>
                    <?php $__currentLoopData = $lgas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($lga->name != $vendor->lga): ?>
                            <option><?php echo e($lga->name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="area">Area</label>
                    <select name="area" class="form-control" id="area">
                        <option value="<?php echo e($vendor->area); ?>"><?php echo e($vendor->area); ?></option>
                        <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($area->name != $vendor->area): ?>
                                <option><?php echo e($area->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
            </div>
        </div>
        <div class="row">
          <div class="form-group col-sm-8">
                <label for="street">Address</label>
                <input name="address" class="form-control" id="street" type="text" value="<?php echo e($vendor->address); ?>">
          </div>
          <div class="form-group col-sm-4">
            <label for="postal-code">Postal Code</label>
            <input name="zip" class="form-control" id="postal-code" type="text" value="<?php echo e($vendor->zip); ?>">
          </div>
        </div>
        <!-- /.row-->

        <div class="row">
          <div class="form-group col-sm-6">
            <label for="open">Opening Hours</label>
            <input name="open" class="form-control" id="open" type="text" value="<?php echo e($vendor->opening); ?>">
          </div>
          <div class="form-group col-sm-6">
            <label for="close">Closing Hours</label>
            <input name="close" class="form-control" id="close" type="text" value="<?php echo e($vendor->closing); ?>">
          </div>
        </div>

      </div>
    </div>
  </div>

  <div class="col-sm-6">
      <div class="card">

          <div class="card-header">
              Upload Image/Cover
          </div>

          <div class="card-body">

            <div class="form-group">
               <label for="vendor-image">Image</label>
               <div class="vendor-image-container">
                    <div class="vendor-image" style="background-image: url('<?php echo e($vendor->image); ?>')" data-init="<?php echo e($vendor->image); ?>"></div>
                    <div class="vendor-image-txt">Click here to select image from file</div>
                </div>
               <input name="vendor-image" class="form-control" style="display:none;" id="vendor-image-file" type="file">
            </div><br>

            <div class="form-group">
                <label for="cover">Cover</label>
                <div class="cover-container">
                     <div class="cover-image" style="background-image: url('<?php echo e($vendor->cover); ?>')" data-init="<?php echo e($vendor->cover); ?>"></div>
                     <div class="cover-txt">Click here to select image from file</div>
                 </div>
                <input name="cover" class="form-control" style="display:none;" id="cover-file" type="file">
             </div>
            <div class="form-group">
               <label for="send"></label>
               <button id="send" class="btn btn-sm btn-danger form-control " id="editVendorFormBtn" type="submit">Save edit & Upload</button>
            </div>
          </div>

      </div>
  </div>

</div>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coreui\resources\views/admin/pages/vendor/edit.blade.php ENDPATH**/ ?>