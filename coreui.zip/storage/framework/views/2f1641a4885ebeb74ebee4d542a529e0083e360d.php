<?php $__env->startSection('content'); ?>

<div class="row null" >

<div class="col-md-6">
    <div class="card">
      <div class="card-header"><i class="fa fa-align-justify"></i> &nbsp; <b><?php echo e($rider->firstname." ".$rider->lastname); ?> (Rider)</b></div>
      <div class="card-body">

        <center>
            <div class="passport-container">
                <div class="cover-image" style="background-image:url('<?php echo e($rider->image); ?>');"></div>
            </div>
        </center>
        <div style="margin-top: 20px;">
            <table class="table table-striped">
                <tbody>
                    <tr>
                        <td><b>Status</b></td>
                        <td>
                            <?php if($rider->active != NULL): ?>
                                <span class="badge badge-success">Active</span>
                            <?php else: ?>
                                <span class="badge badge-danger">inActive</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td><b>Username</b></td>
                        <td><?php echo e($rider->username); ?></td>
                    </tr>
                    <tr>
                        <td><b>Category</b></td>
                        <td>
                            <?php if($rider->category == "Bike"): ?>
                                <i class="fa fa-biking"></i> &nbsp;
                            <?php endif; ?>
                            <?php if($rider->category == "Car"): ?>
                                <i class="fa fa-car"></i> &nbsp;
                            <?php endif; ?>
                            <?php if($rider->category == "Bus"): ?>
                                <i class="fa fa-bus"></i> &nbsp;
                            <?php endif; ?>

                            <?php echo e($rider->category); ?>

                        </td>
                    </tr>
                    <tr>
                        <td><b>Location Assigned</b></td>
                        <td>
                            <?php if($rider->location_assigned == NULL): ?>
                                <span class="text-danger">Unassigned</span>
                            <?php else: ?>
                                <?php echo e($rider->location_assigned); ?>

                                <?php if($rider->location_description !== NULL): ?>
                                    - <small><?php echo e($rider->location_description); ?></small>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td><b>Vehicle Plate</b></td>
                        <td><?php echo e($rider->plate_number); ?></td>
                    </tr>
                    <tr>
                        <td><b>Company</b></td>
                        <td><?php echo e($rider->company); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>

      </div>
    </div><br>
</div>

<div class="col-md-6">
    <div class="card">
      <div class="card-header"><i class="fa fa-align-justify"></i> <b>More</b></div>
      <div class="card-body">
        <div style="margin-top: 0px;">
            <table class="table table-striped">
                <tbody>
                    <tr>
                        <td><b>Email</b></td>
                        <td><?php echo e($rider->email); ?></td>
                    </tr>
                    <tr>
                        <td><b>Fullname</b></td>
                        <td><?php echo e($rider->firstname." ".$rider->lastname); ?></td>
                    </tr>
                    <tr>
                        <td><b>Contact</b></td>
                        <td><?php echo e($rider->phone); ?></td>
                    </tr>
                    <tr>
                        <td><b>Address</b></td>
                        <td><?php echo e($rider->address); ?></td>
                    </tr>
                    <tr>
                        <td><b>LGA</b></td>
                        <td><?php echo e($rider->lga); ?></td>
                    </tr>
                    <tr>
                        <td><b>State</b></td>
                        <td><?php echo e($rider->state); ?></td>
                    </tr>
                    <tr>
                        <td><b>Country</b></td>
                        <td><?php echo e($rider->country); ?></td>
                    </tr>
                    <tr>
                        <td><b>Date Of Birth</b></td>
                        <td><?php echo e($rider->date_of_birth); ?></td>
                    </tr>
                    <tr>
                        <td><b>Spouse Name</b></td>
                        <td>
                            <?php echo e($rider->spouse_name); ?>

                        </td>
                    </tr>
                    <tr>
                        <td><b>Spouse Phone</b></td>
                        <td>
                            <?php echo e($rider->spouse_phone); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

      </div>
    </div>
</div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coreui\resources\views/admin/pages/rider/single.blade.php ENDPATH**/ ?>