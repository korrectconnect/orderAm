<?php $__env->startSection('content'); ?>

<div class="breadcrumb-wrapper">

    <div class="container">

        <ol class="breadcrumb-list booking-step">
            <li><a href="#">Home</a></li>
            <li><span>Address Book</span></li>
        </ol>

    </div>

</div>
<!-- end breadcrumb -->

<div class="admin-container-wrapper">

    <div class="container">

        <div class="GridLex-gap-15-wrappper">

            <div class="GridLex-grid-noGutter-equalHeight">

                <div class="GridLex-col-3_sm-4_xs-12">

                    <div class="admin-sidebar">

                        <div class="admin-user-item">

                            <?php if(auth()->user()->image != NULL): ?>
                                <div class="image" style="background-image: url('<?php echo e(auth()->user()->image); ?>')"></div>
                            <?php else: ?>
                                <div class="image" style="background-image: url('<?php echo e(asset('images/man/01.jpg')); ?>')"></div>
                            <?php endif; ?>

                            <h4><?php echo e(auth()->user()->firstname." ".auth()->user()->lastname); ?></h4>
                            <p class="user-role"><?php echo e(auth()->user()->email); ?></p>

                        </div>

                        <div class="admin-user-action text-center">

                            <a class="btn btn-primary btn-sm" href="javascript:void()" onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();"><i class="fa fa-door-open"></i> Logout</a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>

                        </div>

                        <ul class="admin-user-menu clearfix">
                            <li>
                                <a href="<?php echo e(route('user.profile')); ?>"><i class="fa fa-user"></i> Profile</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('user.orders')); ?>"><i class="fa fa-list"></i> My Orders</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('user.address.book')); ?>"><i class="fa fa-book"></i> Address Book</a>
                            </li>
                            <li class="active">
                                <a href="<?php echo e(route('user.vendor.favourite')); ?>"><i class="fa fa-heart"></i> Favourite Vendors</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('user.password.change')); ?>"><i class="fa fa-key"></i> Change Password</a>
                            </li>

                        </ul>

                    </div>

                </div>

                <div class="GridLex-col-9_sm-8_xs-12">

                    <div class="admin-content-wrapper">

                        <div class="admin-section-title">

                            <h2>Favourite Vendors</h2>

                        </div>

                        <div class="company-grid-wrapper top-company-2-wrapper">

                            <div class="GridLex-gap-30">

                                <div class="GridLex-grid-noGutter-equalHeight">

                                    <?php if($vendors->count() >= 1): ?>

                                        <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <div class="GridLex-col-3_sm-4_xs-6_xss-12">

                                            <div class="top-company-2">
                                                <a href="<?php echo e(route('user.vendor', ['id' => $vendor->id, 'name' => $vendor->type])); ?>">

                                                    <div class="image">
                                                        <img src="<?php echo e($vendor->image); ?>" alt="image" />
                                                    </div>

                                                    <div class="content">
                                                        <h5 class="heading text-primary font700"><?php echo e($vendor->name); ?></h5>
                                                        <p class="texting font600">Fresh baked/cooked meal and much more...</p>
                                                        <p class="mata-p clearfix"><span class="text-primary font700">&#8358; <?php echo e($vendor->price); ?></span> <span class="font13">min order</span> <span class="pull-right icon"><i class="fa fa-long-arrow-right"></i></span></p>

                                                    </div>


                                                </a>

                                            </div>

                                        </div>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php else: ?>

                                        <center>
                                            <h2 style="color: rgb(100, 100, 100)"><i class="fa fa-heart"></i></h2>
                                            <h3>You have not added any vendor to your favourites</h3>
                                            <div>
                                                Click the button below to browse the best vendors near by<br><br>

                                                <a href="<?php echo e(route('user.vendors.home')); ?>" class="btn btn-primary btn-md">Browse Vendors</a>
                                            </div>
                                        </center>

                                    <?php endif; ?>

                                </div>
                            </div>
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coreui\resources\views/user/pages/fav_vendors.blade.php ENDPATH**/ ?>