<center>

    <img src="<?php echo e(asset('images/404.gif')); ?>" alt="" srcset="">

    <h3>Oops... Page Not Found!</h3>

</center>
<?php /**PATH C:\xampp\htdocs\coreui\resources\views/user/ajax/404.blade.php ENDPATH**/ ?>