<?php if($orders->count() >= 1): ?>

    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="alert alert-secondary">
            <b>Date : </b> <?php echo e($order->created_at); ?><br>
            <b>Customer Name : </b> <?php echo e($order->firstname." ".$order->lastname); ?><br>
            <b>Customer Line 1 : </b> <?php echo e($order->user_phone); ?><br>
            <b>Customer Line 2 : </b> <?php echo e($order->phone); ?><br>
            <b>Total : </b> &#8358;<?php echo e($order->total); ?><br>
            <b>Vendor : </b> <?php echo e($order->name); ?> (<?php echo e($order->vendor_lga); ?>, <?php echo e($order->vendor_state); ?>)<br>
            <b>Address : </b> <?php echo e($order->address); ?> (<?php echo e($order->lga.", ".$order->state); ?>)<br>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php else: ?>
    <div class="alert alert-secondary">
        <?php echo e($rider->firstname." ".$rider->lastname); ?> does not have any pending order
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\coreui\resources\views/admin/pages/ajax/rider_orders.blade.php ENDPATH**/ ?>