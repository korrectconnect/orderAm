@extends('dashboard.authBase')

@section('content')

    <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-8">
          <div class="card-group">
            <div class="card p-4">
              <div class="card-body">
                <h1>Login</h1>
                <p class="text-muted">Sign In to your account</p>
                <form method="POST" action="{{ route('admin.login') }}">
                    @csrf
                    <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text">
                        <i class="fa fa-user"></i>
                      </span>
                    </div>
                    <input class="form-control" type="text" placeholder="{{ __('Admin ID') }}" name="user_id" value="{{ old('user_id') }}" required autofocus>
                    </div>
                    <div class="input-group mb-4">
                    <div class="input-group-prepend">
                      <span class="input-group-text">
                        <i class="fa fa-lock"></i>
                      </span>
                    </div>
                    <input class="form-control" type="password" placeholder="{{ __('Password') }}" name="password" required>
                    </div>
                    <div class="row">
                    <div class="col-6">
                        <button class="btn btn-primary px-4" type="submit">{{ __('Login') }}</button>
                    </div>
                    </form>
                    <div class="col-6 text-right">
                        <a href="{{route('admin.register')}}" class="btn btn-link px-0">Register</a>
                    </div>
                    </div>
              </div>
            </div>
            <div class="card text-white py-5 d-md-down-none" style="width:44%; background-color:rgb(0,0,80);">
              <div class="card-body text-center">
                <div>
                    <img src="{{asset('assets/brand/logo.png')}}" alt="Logo" style="width:70px;"><br><br>
                    <h2>{{env('APP_NAME')}}</h2>
                  <p><small>Admin Panel Login</small></p>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

@endsection

@section('javascript')

@endsection
