<center>

    <img src="{{asset('images/404.gif')}}" alt="" srcset="">

    <h3>Oops... Page Not Found!</h3>

</center>
