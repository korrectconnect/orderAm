<footer class="c-footer">
  <div><a href="kocots.com">Kocots</a> &copy; {{date('Y')}}.</div>
  <div class="ml-auto">Powered by&nbsp;<a href="kocots.com">Korrect Connect</a></div>
</footer>
