<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Vendor_category extends Model
{
    //
    protected $table = "vendor_category" ;
}
