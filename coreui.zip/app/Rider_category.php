<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Rider_category extends Model
{
    //
    protected $table = 'rider_category' ;
}
