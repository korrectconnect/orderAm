<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Rider_order extends Model
{
    //
}
